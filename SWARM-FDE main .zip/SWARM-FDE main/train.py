import os
import sys
import argparse
import time
from pathlib import Path

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import DataLoader
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from models.mixvpr import VPRModel
from models.losses import MultiSimilarityLoss, TripletMarginLoss
from utils.evaluation import compute_recall_at_k
from dataset.alto import create_alto_dataloaders
from dataset.coperception_uav import create_coperception_dataloaders


def parse_args():
    parser = argparse.ArgumentParser(description='Swarm-FDE UAV VPR Training')

    parser.add_argument('--dataset', type=str, default='coperception',
                        choices=['alto', 'coperception'])
    parser.add_argument('--dataset_root', type=str, default='./data/CoPerception-UAV')
    parser.add_argument('--img_size', type=int, nargs=2, default=[320, 320])
    parser.add_argument('--mini', action='store_true')

    parser.add_argument('--camera_mode', type=str, default='bev',
                        choices=['bev', 'front', 'back', 'side', 'all', 'directional'])
    parser.add_argument('--temporal_stride', type=int, default=1)
    parser.add_argument('--train_split', type=str, default='train')
    parser.add_argument('--val_split', type=str, default='validate')

    parser.add_argument('--backbone', type=str, default='resnet18',
                        choices=['resnet18', 'resnet50'])
    parser.add_argument('--out_dim', type=int, default=4096)
    parser.add_argument('--mix_depth', type=int, default=4)
    parser.add_argument('--out_channels', type=int, default=256)
    parser.add_argument('--out_rows', type=int, default=4)

    parser.add_argument('--use_fde', action='store_true')
    parser.add_argument('--fde_beta', type=float, default=0.8)
    parser.add_argument('--fde_time', type=float, default=1.0)
    parser.add_argument('--fde_step_size', type=float, default=0.25)
    parser.add_argument('--fde_method', type=str, default='predictor',
                        choices=['predictor', 'corrector', 'l1', 'gl'])

    parser.add_argument('--swarm', action='store_true')
    parser.add_argument('--swarm_size', type=int, default=3)
    parser.add_argument('--swarm_stride', type=int, default=2)
    parser.add_argument('--swarm_beta', type=float, default=0.8)
    parser.add_argument('--swarm_time', type=float, default=1.0)
    parser.add_argument('--swarm_step_size', type=float, default=0.25)

    parser.add_argument('--epochs', type=int, default=30)
    parser.add_argument('--lr', type=float, default=1e-4)
    parser.add_argument('--weight_decay', type=float, default=1e-4)
    parser.add_argument('--places_per_batch', type=int, default=8)
    parser.add_argument('--images_per_place', type=int, default=4)
    parser.add_argument('--groups_per_place', type=int, default=2)
    parser.add_argument('--loss_type', type=str, default='ms',
                        choices=['ms', 'triplet', 'contrastive'])

    parser.add_argument('--eval_every', type=int, default=5)
    parser.add_argument('--save_dir', type=str, default='./checkpoints')
    parser.add_argument('--device', type=str, default='auto')
    parser.add_argument('--seed', type=int, default=42)

    return parser.parse_args()


def train_one_epoch(model, dataloader, criterion, optimizer, device, epoch, is_swarm=False):
    model.train()
    total_loss = 0.0
    num_batches = 0

    for batch_idx, (images, labels) in enumerate(dataloader):
        images = images.to(device)
        labels = labels.to(device)

        optimizer.zero_grad()
        descriptors = model(images)
        loss = criterion(descriptors, labels)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()

        total_loss += loss.item()
        num_batches += 1

        if (batch_idx + 1) % 10 == 0 or (batch_idx + 1) == len(dataloader):
            avg_loss = total_loss / num_batches
            print(f"  Epoch [{epoch}] Batch [{batch_idx+1}/{len(dataloader)}] "
                  f"Loss: {loss.item():.4f} (avg: {avg_loss:.4f})")

    return total_loss / max(num_batches, 1)


@torch.no_grad()
def validate(model, query_loader, db_loader, device):
    model.eval()

    def _to_numpy(t):
        return t.numpy() if isinstance(t, torch.Tensor) else np.array(t)

    db_descs, db_labels = [], []
    for images, labels in db_loader:
        descs = model(images.to(device)).cpu().numpy()
        db_descs.append(descs)
        db_labels.append(_to_numpy(labels))
    db_descs = np.concatenate(db_descs)
    db_labels = np.concatenate(db_labels)

    q_descs, q_labels = [], []
    for images, labels in query_loader:
        descs = model(images.to(device)).cpu().numpy()
        q_descs.append(descs)
        q_labels.append(_to_numpy(labels))
    q_descs = np.concatenate(q_descs)
    q_labels = np.concatenate(q_labels)

    results = compute_recall_at_k(
        q_descs, q_labels,
        db_descs, db_labels,
        k_values=[1, 5, 10, 20]
    )

    return results


def main():
    args = parse_args()

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    if args.device == 'auto':
        if torch.cuda.is_available():
            device = torch.device('cuda')
        elif torch.backends.mps.is_available():
            device = torch.device('mps')
        else:
            device = torch.device('cpu')
    else:
        device = torch.device(args.device)
    print(f"\n[device] {device}")

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)

    is_swarm = args.swarm
    if is_swarm:
        mode_str = "Swarm-FDE"
        if args.use_fde:
            mode_str += " + single-view FDE"
    elif args.use_fde:
        mode_str = "FDE-MixVPR"
    else:
        mode_str = "baseline MixVPR"

    dataset_name = 'CoPerception-UAV' if args.dataset == 'coperception' else 'ALTO'

    print(f"\n{'='*60}")
    print(f"  mode: {mode_str}")
    print(f"  dataset: {dataset_name}")
    print(f"  path: {args.dataset_root}")
    if args.dataset == 'coperception':
        print(f"  camera: {args.camera_mode}")
    if is_swarm:
        if args.dataset == 'alto':
            print(f"  swarm: N={args.swarm_size}, stride={args.swarm_stride}")
        else:
            print(f"  swarm: N={args.swarm_size} UAVs, camera={args.camera_mode}")
        print(f"  SwarmFDE: beta={args.swarm_beta}, T={args.swarm_time}, h={args.swarm_step_size}")
    if args.use_fde:
        print(f"  FDE: beta={args.fde_beta}, T={args.fde_time}, h={args.fde_step_size}")
    print(f"{'='*60}")

    if args.dataset == 'coperception':
        dataloaders = create_coperception_dataloaders(
            dataset_root=args.dataset_root,
            mode='swarm' if is_swarm else 'single',
            swarm_size=args.swarm_size,
            camera_mode=args.camera_mode,
            img_size=tuple(args.img_size),
            places_per_batch=args.places_per_batch,
            groups_per_place=args.groups_per_place,
            images_per_place=args.images_per_place,
            num_workers=4,
            max_places=20 if args.mini else None,
            max_groups=100 if args.mini else None,
            temporal_stride=args.temporal_stride,
            train_split=args.train_split,
            val_split=args.val_split,
        )
    else:
        dataloaders = create_alto_dataloaders(
            dataset_root=args.dataset_root,
            mode='swarm' if is_swarm else 'single',
            swarm_size=args.swarm_size,
            swarm_stride=args.swarm_stride,
            img_size=tuple(args.img_size),
            places_per_batch=args.places_per_batch,
            groups_per_place=args.groups_per_place,
            images_per_place=args.images_per_place,
            num_workers=4,
            max_places=20 if args.mini else None,
            max_groups=100 if args.mini else None,
        )

    if is_swarm and args.dataset == 'coperception':
        from dataset.coperception_uav import CoPerceptionDataset
        n_cameras = len(CoPerceptionDataset._resolve_camera_ids(args.camera_mode))
        model_swarm_size = args.swarm_size * n_cameras
        if n_cameras > 1:
            print(f"\n[views] {args.swarm_size} UAVs × {n_cameras} cameras = {model_swarm_size}")
    else:
        model_swarm_size = args.swarm_size

    print("\n[model] building...")

    if is_swarm:
        from models.swarm_fde import SwarmVPRModel

        model = SwarmVPRModel(
            backbone_name=args.backbone,
            out_dim=args.out_dim,
            swarm_size=model_swarm_size,
            out_channels=args.out_channels,
            out_rows=args.out_rows,
            img_size=tuple(args.img_size),
            swarm_beta=args.swarm_beta,
            swarm_time=args.swarm_time,
            swarm_step_size=args.swarm_step_size,
            use_single_fde=args.use_fde,
            single_beta=args.fde_beta,
            single_time=args.fde_time,
            single_step_size=args.fde_step_size,
            fde_method=args.fde_method,
        ).to(device)
    else:
        model = VPRModel(
            backbone_name=args.backbone,
            out_dim=args.out_dim,
            mix_depth=args.mix_depth,
            out_channels=args.out_channels,
            out_rows=args.out_rows,
            img_size=tuple(args.img_size),
            use_fde=args.use_fde,
            fde_beta=args.fde_beta,
            fde_time=args.fde_time,
            fde_step_size=args.fde_step_size,
            fde_method=args.fde_method,
        ).to(device)

    if args.loss_type == 'ms':
        criterion = MultiSimilarityLoss(alpha=2.0, beta=50.0, margin=0.1)
        print("[loss] Multi-Similarity Loss")
    elif args.loss_type == 'triplet':
        criterion = TripletMarginLoss(margin=0.1, mining='hard')
        print("[loss] Triplet Margin Loss")
    else:
        from models.losses import ContrastiveLoss
        criterion = ContrastiveLoss(temperature=0.07)
        print("[loss] Contrastive Loss (InfoNCE)")

    backbone_params = list(model.backbone.parameters())
    if is_swarm:
        aggregator_params = [p for n, p in model.named_parameters()
                           if 'backbone' not in n and p.requires_grad]
    else:
        aggregator_params = list(model.aggregator.parameters())

    optimizer = optim.Adam([
        {'params': backbone_params, 'lr': args.lr * 0.1},
        {'params': aggregator_params, 'lr': args.lr},
    ], weight_decay=args.weight_decay)

    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=args.epochs, eta_min=1e-6
    )

    print(f"[optimizer] Adam (backbone lr={args.lr*0.1:.1e}, aggregator lr={args.lr:.1e})")

    print(f"\n{'='*60}")
    print("start training")
    print(f"{'='*60}")

    best_recall = 0.0
    training_log = []

    for epoch in range(1, args.epochs + 1):
        print(f"\n{'='*50}")
        print(f"Epoch {epoch}/{args.epochs}")
        print(f"{'='*50}")
        print(f"lr: backbone={optimizer.param_groups[0]['lr']:.2e}, "
              f"aggregator={optimizer.param_groups[1]['lr']:.2e}")

        start_time = time.time()
        avg_loss = train_one_epoch(
            model, dataloaders['train'], criterion, optimizer, device,
            epoch, is_swarm=is_swarm,
        )
        train_time = time.time() - start_time

        print(f"\n  Epoch {epoch} done | avg loss: {avg_loss:.4f} | time: {train_time:.1f}s")

        scheduler.step()

        if epoch % args.eval_every == 0 or epoch == args.epochs:
            print(f"\n  evaluating...")
            results = validate(
                model, dataloaders['val_query'], dataloaders['val_db'], device,
            )

            print(f"  results:")
            for k, v in results.items():
                print(f"    {k}: {v:.2f}%")

            current_recall = results.get('R@1', 0)
            if current_recall > best_recall:
                best_recall = current_recall
                best_path = save_dir / 'best_model.pth'
                torch.save({
                    'epoch': epoch,
                    'model_state_dict': model.state_dict(),
                    'optimizer_state_dict': optimizer.state_dict(),
                    'best_recall': best_recall,
                    'args': vars(args),
                    'model_type': 'swarm' if is_swarm else 'single',
                }, best_path)
                print(f"  saved best model (R@1={best_recall:.2f}%) -> {best_path}")

            training_log.append({
                'epoch': epoch,
                'loss': avg_loss,
                **results
            })

    print(f"\n{'='*60}")
    print("training done!")
    print(f"{'='*60}")
    print(f"  best R@1: {best_recall:.2f}%")
    print(f"  saved to: {save_dir}")

    log_path = save_dir / 'training_log.txt'
    with open(log_path, 'w') as f:
        f.write(f"mode: {mode_str}\n")
        f.write(f"dataset: {dataset_name} ({args.dataset_root})\n")
        if args.dataset == 'coperception':
            f.write(f"camera: {args.camera_mode}\n")
        if is_swarm:
            if args.dataset == 'alto':
                f.write(f"swarm: N={args.swarm_size}, stride={args.swarm_stride}\n")
            else:
                f.write(f"swarm: N={args.swarm_size} UAVs, camera={args.camera_mode}, "
                        f"views={model_swarm_size}\n")
            f.write(f"SwarmFDE: beta={args.swarm_beta}, T={args.swarm_time}, h={args.swarm_step_size}\n")
        if args.use_fde:
            f.write(f"FDE: beta={args.fde_beta}, T={args.fde_time}, h={args.fde_step_size}\n")
        f.write(f"\nEpoch | Loss    | R@1    | R@5    | R@10   | R@20\n")
        f.write("-" * 60 + "\n")
        for entry in training_log:
            f.write(f"{entry['epoch']:5d} | {entry['loss']:.4f} | "
                    f"{entry.get('R@1', 0):6.2f} | {entry.get('R@5', 0):6.2f} | "
                    f"{entry.get('R@10', 0):6.2f} | {entry.get('R@20', 0):6.2f}\n")
    print(f"  log: {log_path}")

    return model


if __name__ == '__main__':
    main()
