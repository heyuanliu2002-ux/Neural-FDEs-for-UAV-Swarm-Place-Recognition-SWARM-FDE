import os
import csv
import random
from pathlib import Path
from typing import Tuple, List, Dict, Optional
from collections import defaultdict

import torch
from torch.utils.data import Dataset, DataLoader, Sampler
import torchvision.transforms as T
from PIL import Image
import numpy as np


def get_train_transforms(img_size: Tuple[int, int] = (320, 320)) -> T.Compose:
    return T.Compose([
        T.Resize(img_size),
        T.RandomCrop(img_size, padding=10),
        T.RandomHorizontalFlip(p=0.5),
        T.RandomVerticalFlip(p=0.3),
        T.RandomRotation(degrees=15),
        T.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.2, hue=0.1),
        T.ToTensor(),
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])


def get_val_transforms(img_size: Tuple[int, int] = (320, 320)) -> T.Compose:
    return T.Compose([
        T.Resize(img_size),
        T.CenterCrop(img_size),
        T.ToTensor(),
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])


def load_gt_matches(csv_path: str) -> Dict[int, int]:
    gt = {}
    with open(csv_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            q_idx = int(row['query_ind'])
            r_idx = int(row['ref_ind'])
            gt[q_idx] = r_idx
    return gt


def load_query_telemetry(csv_path: str) -> Dict[int, Dict]:
    telemetry = {}
    with open(csv_path, 'r') as f:
        reader = csv.DictReader(f)
        for idx, row in enumerate(reader):
            telemetry[idx] = {
                'easting': float(row['easting']),
                'northing': float(row['northing']),
                'altitude': float(row['altitude']),
                'name': row['name'],
            }
    return telemetry


class ALTODataset(Dataset):
    def __init__(
        self,
        dataset_root: str,
        split: str = 'Train',
        transform=None,
        max_places: Optional[int] = None,
        min_imgs_per_place: int = 2,
        use_reference: bool = False,
    ):
        super().__init__()
        self.root = Path(dataset_root) / split
        self.split = split
        self.transform = transform or get_val_transforms()
        self.use_reference = use_reference

        self.images: List[str] = []
        self.labels: List[int] = []
        self.place_to_indices: Dict[int, List[int]] = defaultdict(list)
        self.is_query: List[bool] = []

        self._load_data(max_places, min_imgs_per_place)

    def _load_data(self, max_places: Optional[int], min_imgs_per_place: int):
        query_dir = self.root / 'query_images'
        gt_path = self.root / 'gt_matches.csv'

        if not query_dir.exists():
            print(f"[warning] query dir not found: {query_dir}")
            return
        if not gt_path.exists():
            print(f"[warning] gt file not found: {gt_path}")
            return

        gt_matches = load_gt_matches(str(gt_path))

        place_queries: Dict[int, List[str]] = defaultdict(list)
        query_files = sorted([
            f for f in os.listdir(query_dir)
            if f.lower().endswith('.png')
        ])

        for fname in query_files:
            q_idx = int(fname.replace('.png', ''))
            if q_idx in gt_matches:
                ref_idx = gt_matches[q_idx]
                place_queries[ref_idx].append(str(query_dir / fname))

        valid_places = {
            pid: imgs for pid, imgs in place_queries.items()
            if len(imgs) >= min_imgs_per_place
        }

        place_ids = sorted(valid_places.keys())
        if max_places and len(place_ids) > max_places:
            place_ids = place_ids[:max_places]

        for pid in place_ids:
            for img_path in sorted(valid_places[pid]):
                idx = len(self.images)
                self.images.append(img_path)
                self.labels.append(pid)
                self.place_to_indices[pid].append(idx)
                self.is_query.append(True)

        if self.use_reference:
            ref_dir = self.root / 'reference_images' / 'offset_0_None'
            if ref_dir.exists():
                ref_files = sorted([
                    f for f in os.listdir(ref_dir)
                    if f.lower().endswith('.png')
                ])
                for fname in ref_files:
                    r_idx = int(fname.replace('.png', ''))
                    if r_idx in [pid for pid in place_ids]:
                        idx = len(self.images)
                        self.images.append(str(ref_dir / fname))
                        self.labels.append(r_idx)
                        self.place_to_indices[r_idx].append(idx)
                        self.is_query.append(False)

        print(f"  [{self.split}] {len(self.place_to_indices)} places, "
              f"{len(self.images)} images"
              f" (query: {sum(self.is_query)}"
              f"{f', ref: {len(self.images) - sum(self.is_query)}' if self.use_reference else ''})")

    def __len__(self) -> int:
        return len(self.images)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int]:
        img = Image.open(self.images[idx]).convert('RGB')
        if self.transform:
            img = self.transform(img)
        return img, self.labels[idx]


class ALTOSwarmDataset(Dataset):
    def __init__(
        self,
        dataset_root: str,
        split: str = 'Train',
        swarm_size: int = 3,
        swarm_stride: int = 2,
        transform=None,
        max_groups: Optional[int] = None,
    ):
        super().__init__()
        self.root = Path(dataset_root) / split
        self.split = split
        self.swarm_size = swarm_size
        self.swarm_stride = swarm_stride
        self.transform = transform or get_val_transforms()

        self.groups: List[Dict] = []
        self.place_to_groups: Dict[int, List[int]] = defaultdict(list)

        self._build_swarm_groups(max_groups)

    def _build_swarm_groups(self, max_groups: Optional[int]):
        query_dir = self.root / 'query_images'
        gt_path = self.root / 'gt_matches.csv'

        if not query_dir.exists() or not gt_path.exists():
            print(f"[warning] incomplete data: {self.root}")
            return

        gt_matches = load_gt_matches(str(gt_path))

        query_files = sorted([
            f for f in os.listdir(query_dir)
            if f.lower().endswith('.png')
        ])

        idx_to_path = {}
        for fname in query_files:
            q_idx = int(fname.replace('.png', ''))
            idx_to_path[q_idx] = str(query_dir / fname)

        all_indices = sorted(idx_to_path.keys())

        if len(all_indices) == 0:
            print(f"[warning] no query images found")
            return

        span = (self.swarm_size - 1) * self.swarm_stride

        for start_pos in range(0, len(all_indices) - span, self.swarm_stride):
            frame_indices = [
                all_indices[start_pos + k * self.swarm_stride]
                for k in range(self.swarm_size)
            ]

            if not all(fi in gt_matches for fi in frame_indices):
                continue

            center_idx = frame_indices[self.swarm_size // 2]
            place_id = gt_matches[center_idx]

            group_idx = len(self.groups)
            self.groups.append({
                'frame_paths': [idx_to_path[fi] for fi in frame_indices],
                'frame_indices': frame_indices,
                'place_id': place_id,
                'center_idx': center_idx,
            })
            self.place_to_groups[place_id].append(group_idx)

        if max_groups and len(self.groups) > max_groups:
            self.groups = self.groups[:max_groups]
            self.place_to_groups = defaultdict(list)
            for gi, g in enumerate(self.groups):
                self.place_to_groups[g['place_id']].append(gi)

        print(f"  [{self.split}-Swarm] N={self.swarm_size}, stride={self.swarm_stride}")
        print(f"    {len(self.groups)} groups, {len(self.place_to_groups)} places, "
              f"spacing~{self.swarm_stride * 2.5:.1f}m")

    def __len__(self) -> int:
        return len(self.groups)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int]:
        group = self.groups[idx]

        images = []
        for path in group['frame_paths']:
            img = Image.open(path).convert('RGB')
            if self.transform:
                img = self.transform(img)
            images.append(img)

        swarm_images = torch.stack(images, dim=0)
        return swarm_images, group['place_id']


class SwarmPlaceSampler(Sampler):
    def __init__(
        self,
        place_to_groups: Dict[int, List[int]],
        places_per_batch: int = 4,
        groups_per_place: int = 2,
    ):
        self.place_to_groups = place_to_groups
        self.places_per_batch = places_per_batch
        self.groups_per_place = groups_per_place

        self.valid_places = [
            p for p, groups in place_to_groups.items()
            if len(groups) >= groups_per_place
        ]

        self.batch_size = places_per_batch * groups_per_place
        print(f"  [SwarmSampler] valid places: {len(self.valid_places)}, "
              f"batch = {places_per_batch}P x {groups_per_place}K = {self.batch_size} groups/batch")

    def __iter__(self):
        random.shuffle(self.valid_places)
        for i in range(0, len(self.valid_places), self.places_per_batch):
            batch_places = self.valid_places[i:i + self.places_per_batch]
            if len(batch_places) < self.places_per_batch:
                continue

            batch_indices = []
            for p in batch_places:
                groups = self.place_to_groups[p]
                selected = random.sample(groups, min(self.groups_per_place, len(groups)))
                batch_indices.extend(selected)

            yield batch_indices

    def __len__(self):
        return len(self.valid_places) // self.places_per_batch


def create_alto_dataloaders(
    dataset_root: str,
    mode: str = 'swarm',
    swarm_size: int = 3,
    swarm_stride: int = 2,
    img_size: Tuple[int, int] = (320, 320),
    places_per_batch: int = 4,
    groups_per_place: int = 2,
    images_per_place: int = 4,
    num_workers: int = 4,
    max_places: Optional[int] = None,
    max_groups: Optional[int] = None,
) -> Dict[str, DataLoader]:
    dataloaders = {}

    if mode == 'swarm':
        print("\n=== loading ALTO train set (swarm mode) ===")
        train_dataset = ALTOSwarmDataset(
            dataset_root=dataset_root,
            split='Train',
            swarm_size=swarm_size,
            swarm_stride=swarm_stride,
            transform=get_train_transforms(img_size),
            max_groups=max_groups,
        )

        train_sampler = SwarmPlaceSampler(
            place_to_groups=train_dataset.place_to_groups,
            places_per_batch=places_per_batch,
            groups_per_place=groups_per_place,
        )

        dataloaders['train'] = DataLoader(
            train_dataset,
            batch_sampler=train_sampler,
            num_workers=num_workers,
            pin_memory=True,
        )

        print("\n=== loading ALTO val set ===")
        val_dataset = ALTODataset(
            dataset_root=dataset_root,
            split='Val',
            transform=get_val_transforms(img_size),
            max_places=max_places,
            min_imgs_per_place=1,
            use_reference=True,
        )

        query_indices = [i for i, is_q in enumerate(val_dataset.is_query) if is_q]
        ref_indices = [i for i, is_q in enumerate(val_dataset.is_query) if not is_q]

        if len(ref_indices) == 0:
            db_indices_list = []
            q_indices_list = []
            for pid, indices in val_dataset.place_to_indices.items():
                if len(indices) >= 2:
                    split_point = max(1, len(indices) // 2)
                    db_indices_list.extend(indices[:split_point])
                    q_indices_list.extend(indices[split_point:])
                else:
                    db_indices_list.extend(indices)
            query_indices = q_indices_list
            ref_indices = db_indices_list

        val_batch = places_per_batch * groups_per_place

        dataloaders['val_query'] = DataLoader(
            torch.utils.data.Subset(val_dataset, query_indices),
            batch_size=val_batch,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=True,
        )
        dataloaders['val_db'] = DataLoader(
            torch.utils.data.Subset(val_dataset, ref_indices),
            batch_size=val_batch,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=True,
        )

        print(f"  [val] query: {len(query_indices)}, database: {len(ref_indices)}")

    else:
        print("\n=== loading ALTO train set (single mode) ===")
        train_dataset = ALTODataset(
            dataset_root=dataset_root,
            split='Train',
            transform=get_train_transforms(img_size),
            max_places=max_places,
            min_imgs_per_place=images_per_place,
        )

        from dataset.gsv_cities import PlaceSampler
        train_sampler = PlaceSampler(
            labels=train_dataset.labels,
            place_to_indices=train_dataset.place_to_indices,
            places_per_batch=places_per_batch,
            images_per_place=images_per_place,
        )

        dataloaders['train'] = DataLoader(
            train_dataset,
            batch_sampler=train_sampler,
            num_workers=num_workers,
            pin_memory=True,
        )

        print("\n=== loading ALTO val set (single mode) ===")
        val_dataset = ALTODataset(
            dataset_root=dataset_root,
            split='Val',
            transform=get_val_transforms(img_size),
            max_places=max_places,
            min_imgs_per_place=1,
            use_reference=True,
        )

        query_indices = [i for i, is_q in enumerate(val_dataset.is_query) if is_q]
        ref_indices = [i for i, is_q in enumerate(val_dataset.is_query) if not is_q]

        if len(ref_indices) == 0:
            db_indices_list = []
            q_indices_list = []
            for pid, indices in val_dataset.place_to_indices.items():
                if len(indices) >= 2:
                    split_point = max(1, len(indices) // 2)
                    db_indices_list.extend(indices[:split_point])
                    q_indices_list.extend(indices[split_point:])
                else:
                    db_indices_list.extend(indices)
            query_indices = q_indices_list
            ref_indices = db_indices_list

        val_batch = places_per_batch * images_per_place

        dataloaders['val_query'] = DataLoader(
            torch.utils.data.Subset(val_dataset, query_indices),
            batch_size=val_batch,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=True,
        )
        dataloaders['val_db'] = DataLoader(
            torch.utils.data.Subset(val_dataset, ref_indices),
            batch_size=val_batch,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=True,
        )

    return dataloaders


if __name__ == '__main__':
    import sys
    root = sys.argv[1] if len(sys.argv) > 1 else '/Users/pc/Desktop/UAV Swarm PR/ALTO'

    print("ALTO dataset test")

    print("\n--- test 1: single mode ---")
    try:
        dataloaders = create_alto_dataloaders(
            dataset_root=root, mode='single', max_places=10, num_workers=0,
        )
        for images, labels in dataloaders['train']:
            print(f"  single batch: images={images.shape}, labels={labels.shape}")
            break
        print("  single mode OK")
    except Exception as e:
        print(f"  single mode failed: {e}")

    print("\n--- test 2: swarm mode ---")
    try:
        dataloaders = create_alto_dataloaders(
            dataset_root=root, mode='swarm', swarm_size=3, swarm_stride=2,
            max_groups=50, num_workers=0,
        )
        for swarm_images, labels in dataloaders['train']:
            print(f"  swarm batch: images={swarm_images.shape}, labels={labels.shape}")
            break
        print("  swarm mode OK")
    except Exception as e:
        print(f"  swarm mode failed: {e}")

    print("\ntest done!")
