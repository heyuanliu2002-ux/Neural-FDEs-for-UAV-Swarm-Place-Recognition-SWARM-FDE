import os
import random
import hashlib
from pathlib import Path
from typing import Tuple, List, Dict, Optional, Set
from collections import defaultdict

import torch
from torch.utils.data import Dataset, DataLoader, Sampler
import torchvision.transforms as T
from PIL import Image
import numpy as np



CAMERA_NAMES = {
    0: 'front',
    1: 'right',
    2: 'left',
    3: 'back',
    4: 'bev',
}

CAMERA_IDS = {v: k for k, v in CAMERA_NAMES.items()}

DEFAULT_CAMERA = 'bev'



def get_train_transforms(img_size: Tuple[int, int] = (320, 320)) -> T.Compose:
 
    return T.Compose([
        T.Resize(img_size),
        T.RandomCrop(img_size, padding=10),
        T.RandomHorizontalFlip(p=0.5),
        T.RandomVerticalFlip(p=0.3),
        T.RandomRotation(degrees=15),
        T.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.2, hue=0.1),
        T.ToTensor(),
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])


def get_val_transforms(img_size: Tuple[int, int] = (320, 320)) -> T.Compose:
    """验证集预处理 (不做数据增强)"""
    return T.Compose([
        T.Resize(img_size),
        T.CenterCrop(img_size),
        T.ToTensor(),
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])




def scan_dataset(
    root_dir: Path,
    camera_ids: List[int],
) -> List[Dict]:
   
    samples = []

    if not root_dir.exists():
        print(f"[警告] 数据目录不存在: {root_dir}")
        return samples

    # 遍历场景文件夹
    scenario_dirs = sorted([
        d for d in root_dir.iterdir()
        if d.is_dir()
    ])

    for scenario_dir in scenario_dirs:
        scenario_name = scenario_dir.name

        # 找到所有 agent 文件夹 (数字命名)
        agent_dirs = sorted([
            d for d in scenario_dir.iterdir()
            if d.is_dir() and d.name.lstrip('-').isdigit()
        ])

        if len(agent_dirs) == 0:
            continue

        # 收集所有时间步
        # 从第一个 agent 目录获取时间步列表
        timestamps = set()
        for agent_dir in agent_dirs:
            for f in agent_dir.iterdir():
                if f.suffix == '.png' and '_camera' in f.name:
                    # 文件名格式: {timestamp}_camera{id}.png
                    ts = f.name.split('_camera')[0]
                    timestamps.add(ts)

        # 如果没有找到 _camera 格式, 尝试其他格式
        if len(timestamps) == 0:
            for agent_dir in agent_dirs:
                for f in agent_dir.iterdir():
                    if f.suffix in ('.png', '.jpg', '.jpeg'):
                        # 尝试纯数字文件名
                        stem = f.stem
                        if stem.isdigit():
                            timestamps.add(stem)

        timestamps = sorted(timestamps)

        for ts in timestamps:
            # 收集该时间步下所有 agent 的所有摄像头图像
            agents_data = {}

            for agent_dir in agent_dirs:
                agent_id = agent_dir.name
                cam_paths = {}

                for cam_id in camera_ids:
                    # 尝试多种文件名格式
                    candidates = [
                        agent_dir / f"{ts}_camera{cam_id}.png",
                        agent_dir / f"{ts}_camera{cam_id}.jpg",
                        agent_dir / f"{ts}_cam{cam_id}.png",
                    ]
                    for cand in candidates:
                        if cand.exists():
                            cam_paths[cam_id] = str(cand)
                            break

                if len(cam_paths) > 0:
                    agents_data[agent_id] = cam_paths

            # 至少需要 2 个 agent 有图像才构成有效的多视角样本
            if len(agents_data) >= 2:
                # 用 (scenario, timestamp) 哈希作为 place_id
                place_hash = hashlib.md5(
                    f"{scenario_name}_{ts}".encode()
                ).hexdigest()
                place_id = int(place_hash[:8], 16) % (10 ** 7)

                samples.append({
                    'scenario': scenario_name,
                    'timestamp': ts,
                    'agents': agents_data,
                    'place_id': place_id,
                })

    return samples


def scan_dataset_flexible(
    root_dir: Path,
    camera_ids: List[int],
) -> List[Dict]:
   
    # 先尝试标准结构
    samples = scan_dataset(root_dir, camera_ids)
    if len(samples) > 0:
        return samples

    # 尝试结构B: root/UAV_X/camera_dir/timestamp.png
    print(f"  标准结构未找到数据, 尝试其他目录结构...")
    samples = _scan_structure_b(root_dir, camera_ids)
    if len(samples) > 0:
        return samples

    # 尝试结构D: 扁平结构, 每个agent只有一个摄像头
    samples = _scan_structure_flat(root_dir)
    if len(samples) > 0:
        return samples

    print(f"  [警告] 未能在 {root_dir} 中找到有效数据")
    return samples


def _scan_structure_b(root_dir: Path, camera_ids: List[int]) -> List[Dict]:
    """结构B: root/UAV_X/camera_dir/timestamp.png"""
    samples = []
    uav_dirs = sorted([
        d for d in root_dir.iterdir()
        if d.is_dir() and ('uav' in d.name.lower() or 'drone' in d.name.lower()
                           or 'agent' in d.name.lower())
    ])

    if len(uav_dirs) == 0:
        return samples

    # 收集 UAV → camera_dir → timestamp → path
    all_data = {}  # {timestamp: {uav_name: {cam_id: path}}}

    for uav_dir in uav_dirs:
        uav_name = uav_dir.name
        cam_dirs = sorted([d for d in uav_dir.iterdir() if d.is_dir()])

        for cam_dir in cam_dirs:
            cam_name = cam_dir.name.lower()
            # 映射 camera 目录名 → camera_id
            cam_id = None
            for cid, cname in CAMERA_NAMES.items():
                if cname in cam_name:
                    cam_id = cid
                    break
            if cam_id is None:
                # 尝试数字编号
                for c in cam_name:
                    if c.isdigit():
                        cam_id = int(c)
                        break
            if cam_id is None or cam_id not in camera_ids:
                continue

            for f in sorted(cam_dir.iterdir()):
                if f.suffix in ('.png', '.jpg', '.jpeg'):
                    ts = f.stem
                    if ts not in all_data:
                        all_data[ts] = {}
                    if uav_name not in all_data[ts]:
                        all_data[ts][uav_name] = {}
                    all_data[ts][uav_name][cam_id] = str(f)

    # 转换为标准格式
    for ts in sorted(all_data.keys()):
        agents_data = all_data[ts]
        if len(agents_data) >= 2:
            place_hash = hashlib.md5(ts.encode()).hexdigest()
            place_id = int(place_hash[:8], 16) % (10 ** 7)
            samples.append({
                'scenario': 'default',
                'timestamp': ts,
                'agents': agents_data,
                'place_id': place_id,
            })

    return samples


def _scan_structure_flat(root_dir: Path) -> List[Dict]:
    """扁平结构: root/scenario/agent/timestamp.png (单摄像头)"""
    samples = []
    scenario_dirs = sorted([d for d in root_dir.iterdir() if d.is_dir()])

    for scenario_dir in scenario_dirs:
        agent_dirs = sorted([
            d for d in scenario_dir.iterdir()
            if d.is_dir() and d.name.lstrip('-').isdigit()
        ])
        if len(agent_dirs) < 2:
            continue

        # 收集所有时间步
        timestamps = set()
        for agent_dir in agent_dirs:
            for f in agent_dir.iterdir():
                if f.suffix in ('.png', '.jpg', '.jpeg'):
                    timestamps.add(f.stem)

        for ts in sorted(timestamps):
            agents_data = {}
            for agent_dir in agent_dirs:
                # 查找该时间步的图像
                for ext in ('.png', '.jpg', '.jpeg'):
                    img_path = agent_dir / f"{ts}{ext}"
                    if img_path.exists():
                        # 单摄像头, 统一放在 cam_id=4 (BEV)
                        agents_data[agent_dir.name] = {4: str(img_path)}
                        break

            if len(agents_data) >= 2:
                place_hash = hashlib.md5(
                    f"{scenario_dir.name}_{ts}".encode()
                ).hexdigest()
                place_id = int(place_hash[:8], 16) % (10 ** 7)
                samples.append({
                    'scenario': scenario_dir.name,
                    'timestamp': ts,
                    'agents': agents_data,
                    'place_id': place_id,
                })

    return samples




class CoPerceptionDataset(Dataset):
    

    def __init__(
        self,
        dataset_root: str,
        split: str = 'train',
        camera_mode: str = 'bev',
        transform=None,
        max_places: Optional[int] = None,
        min_imgs_per_place: int = 2,
    ):
        super().__init__()
        self.root = Path(dataset_root) / split
        self.split = split
        self.camera_mode = camera_mode
        self.transform = transform or get_val_transforms()

        # 确定要使用的摄像头
        self.camera_ids = self._resolve_camera_ids(camera_mode)

        # 数据存储
        self.images: List[str] = []
        self.labels: List[int] = []
        self.place_to_indices: Dict[int, List[int]] = defaultdict(list)
        self.is_query: List[bool] = []

        # 加载数据
        self._load_data(max_places, min_imgs_per_place)

    @staticmethod
    def _resolve_camera_ids(camera_mode: str) -> List[int]:
        """将摄像头模式转换为摄像头 ID 列表"""
        mode = camera_mode.lower()
        if mode == 'bev':
            return [4]
        elif mode == 'front':
            return [0]
        elif mode == 'back':
            return [3]
        elif mode == 'side':
            return [1, 2]  # left + right
        elif mode in ('all', 'multi'):
            return [0, 1, 2, 3, 4]
        elif mode == 'directional':
            return [0, 1, 2, 3]  # 四个方向, 不含 BEV
        else:
            # 尝试解析为逗号分隔的数字
            try:
                return [int(x.strip()) for x in mode.split(',')]
            except ValueError:
                print(f"[警告] 未知摄像头模式 '{camera_mode}', 使用 BEV")
                return [4]

    def _load_data(self, max_places: Optional[int], min_imgs_per_place: int):
        """加载并索引所有图像"""
        print(f"\n=== 扫描 CoPerception-UAV [{self.split}] ===")
        print(f"  摄像头: {[CAMERA_NAMES.get(c, f'cam{c}') for c in self.camera_ids]}")

        # 扫描数据集
        all_samples = scan_dataset_flexible(self.root, self.camera_ids)
        print(f"  发现 {len(all_samples)} 个时间步样本")

        # 按 place_id 组织图像
        place_images: Dict[int, List[str]] = defaultdict(list)

        for sample in all_samples:
            pid = sample['place_id']
            for agent_id, cam_paths in sample['agents'].items():
                for cam_id, img_path in cam_paths.items():
                    if cam_id in self.camera_ids:
                        place_images[pid].append(img_path)

        # 过滤: 每个地点至少需要 min_imgs_per_place 张图
        valid_places = {
            pid: imgs for pid, imgs in place_images.items()
            if len(imgs) >= min_imgs_per_place
        }

        # 限制地点数
        place_ids = sorted(valid_places.keys())
        if max_places and len(place_ids) > max_places:
            place_ids = place_ids[:max_places]

        # 构建数据列表
        for pid in place_ids:
            for img_path in sorted(valid_places[pid]):
                idx = len(self.images)
                self.images.append(img_path)
                self.labels.append(pid)
                self.place_to_indices[pid].append(idx)
                self.is_query.append(True)

        print(f"  [{self.split}] {len(self.place_to_indices)} 个地点, "
              f"{len(self.images)} 张图像")

    def __len__(self) -> int:
        return len(self.images)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int]:
        img = Image.open(self.images[idx]).convert('RGB')
        if self.transform:
            img = self.transform(img)
        return img, self.labels[idx]



class CoPerceptionSwarmDataset(Dataset):
    

    def __init__(
        self,
        dataset_root: str,
        split: str = 'train',
        swarm_size: int = 5,
        camera_mode: str = 'bev',
        transform=None,
        max_groups: Optional[int] = None,
        temporal_stride: int = 1,
    ):
        super().__init__()
        self.root = Path(dataset_root) / split
        self.split = split
        self.swarm_size = swarm_size
        self.camera_mode = camera_mode
        self.transform = transform or get_val_transforms()
        self.temporal_stride = temporal_stride

        # 确定摄像头
        self.camera_ids = CoPerceptionDataset._resolve_camera_ids(camera_mode)

        # 如果 camera_mode='all', 每架 UAV 有多张图, swarm group size 会更大
        self.imgs_per_uav = len(self.camera_ids)
        self.total_views = self.swarm_size * self.imgs_per_uav  # 模型实际看到的视角数

        # 群组数据
        self.groups: List[Dict] = []
        self.place_to_groups: Dict[int, List[int]] = defaultdict(list)

        self._build_groups(max_groups)

    def _build_groups(self, max_groups: Optional[int]):
        
        print(f"\n=== 构建 CoPerception-UAV 群组 [{self.split}] ===")
        print(f"  swarm_size={self.swarm_size}, camera={self.camera_mode}")

        # 扫描数据
        all_samples = scan_dataset_flexible(self.root, self.camera_ids)

        # 按 temporal_stride 采样
        if self.temporal_stride > 1:
            all_samples = all_samples[::self.temporal_stride]

        print(f"  扫描到 {len(all_samples)} 个有效时间步")

        for sample in all_samples:
            # 收集该时间步所有 UAV 的图像路径
            # agents_data: {agent_id: {cam_id: path}}
            available_agents = []
            for agent_id, cam_paths in sample['agents'].items():
                # 检查该 agent 是否有所需的全部摄像头
                valid_cams = {
                    cid: path for cid, path in cam_paths.items()
                    if cid in self.camera_ids
                }
                if len(valid_cams) == len(self.camera_ids):
                    available_agents.append({
                        'agent_id': agent_id,
                        'cam_paths': valid_cams,
                    })

            # 需要至少 swarm_size 架 UAV
            if len(available_agents) < self.swarm_size:
                continue

            # 构建群组
            group_idx = len(self.groups)
            self.groups.append({
                'available_agents': available_agents,
                'place_id': sample['place_id'],
                'scenario': sample['scenario'],
                'timestamp': sample['timestamp'],
            })
            self.place_to_groups[sample['place_id']].append(group_idx)

        # 限制群组数
        if max_groups and len(self.groups) > max_groups:
            self.groups = self.groups[:max_groups]
            self.place_to_groups = defaultdict(list)
            for gi, g in enumerate(self.groups):
                self.place_to_groups[g['place_id']].append(gi)

        # 尝试为跨时间步的临近地点创建正样本关系
        self._build_temporal_positives()

        print(f"  [{self.split}-Swarm] {len(self.groups)} 个群组, "
              f"{len(self.place_to_groups)} 个地点")
        if len(self.groups) > 0:
            n_agents = len(self.groups[0]['available_agents'])
            print(f"  每时间步平均 {n_agents} 架 UAV 可用, "
                  f"每群组取 {self.swarm_size} 架")

    def _build_temporal_positives(self):
        
        temporal_window = 3  # 连续 3 个时间步算同一地点

        # 按场景分组
        scenario_groups: Dict[str, List[int]] = defaultdict(list)
        for gi, g in enumerate(self.groups):
            scenario_groups[g['scenario']].append(gi)

        # 在每个场景内, 将连续时间步的群组合并为同一 place_id
        new_place_to_groups: Dict[int, List[int]] = defaultdict(list)
        reassigned = 0

        for scenario, group_indices in scenario_groups.items():
            # 按时间步排序
            sorted_indices = sorted(group_indices,
                                     key=lambda gi: self.groups[gi]['timestamp'])

            # 每 temporal_window 个连续时间步共享一个 place_id
            for i in range(0, len(sorted_indices), temporal_window):
                window = sorted_indices[i:i + temporal_window]
                if len(window) < 2:
                    continue

                # 用第一个群组的 place_id 作为共享 ID
                shared_pid = self.groups[window[0]]['place_id']
                for gi in window:
                    old_pid = self.groups[gi]['place_id']
                    if old_pid != shared_pid:
                        self.groups[gi]['place_id'] = shared_pid
                        reassigned += 1

        # 重建 place_to_groups
        self.place_to_groups = defaultdict(list)
        for gi, g in enumerate(self.groups):
            self.place_to_groups[g['place_id']].append(gi)

        if reassigned > 0:
            print(f"  时间正样本: 合并了 {reassigned} 个群组, "
                  f"现在 {len(self.place_to_groups)} 个独立地点")

    @property
    def views_per_group(self) -> int:
       
        return self.total_views

    def __len__(self) -> int:
        return len(self.groups)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int]:
        
        group = self.groups[idx]
        available = group['available_agents']

        # 选择 UAV (训练时随机选, 测试时固定)
        if self.split == 'train' and len(available) > self.swarm_size:
            selected = random.sample(available, self.swarm_size)
        else:
            selected = available[:self.swarm_size]

        # 加载图像
        images = []
        for agent_info in selected:
            for cam_id in sorted(agent_info['cam_paths'].keys()):
                img_path = agent_info['cam_paths'][cam_id]
                img = Image.open(img_path).convert('RGB')
                if self.transform:
                    img = self.transform(img)
                images.append(img)

        # 堆叠: (N * n_cams, 3, H, W)
        swarm_images = torch.stack(images, dim=0)

        return swarm_images, group['place_id']




class PlaceSampler(Sampler):
   

    def __init__(
        self,
        labels: List[int],
        place_to_indices: Dict[int, List[int]],
        places_per_batch: int = 4,
        images_per_place: int = 4,
    ):
        self.place_to_indices = place_to_indices
        self.places_per_batch = places_per_batch
        self.images_per_place = images_per_place

        self.valid_places = [
            p for p, indices in place_to_indices.items()
            if len(indices) >= images_per_place
        ]

        self.batch_size = places_per_batch * images_per_place
        print(f"  [PlaceSampler] 有效地点: {len(self.valid_places)}, "
              f"batch = {places_per_batch}P × {images_per_place}K = {self.batch_size}")

    def __iter__(self):
        random.shuffle(self.valid_places)
        for i in range(0, len(self.valid_places), self.places_per_batch):
            batch_places = self.valid_places[i:i + self.places_per_batch]
            if len(batch_places) < self.places_per_batch:
                continue

            batch_indices = []
            for p in batch_places:
                indices = self.place_to_indices[p]
                selected = random.sample(indices,
                                         min(self.images_per_place, len(indices)))
                batch_indices.extend(selected)

            yield batch_indices

    def __len__(self):
        return len(self.valid_places) // self.places_per_batch




class SwarmPlaceSampler(Sampler):
    """
    群组级别 PK 采样器
    每 batch: P 个地点 × K 个群组 × N 个视角
    """

    def __init__(
        self,
        place_to_groups: Dict[int, List[int]],
        places_per_batch: int = 4,
        groups_per_place: int = 2,
    ):
        self.place_to_groups = place_to_groups
        self.places_per_batch = places_per_batch
        self.groups_per_place = groups_per_place

        self.valid_places = [
            p for p, groups in place_to_groups.items()
            if len(groups) >= groups_per_place
        ]

        self.batch_size = places_per_batch * groups_per_place
        print(f"  [SwarmSampler] 有效地点: {len(self.valid_places)}, "
              f"batch = {places_per_batch}P × {groups_per_place}K = {self.batch_size} 群组/batch")

    def __iter__(self):
        random.shuffle(self.valid_places)
        for i in range(0, len(self.valid_places), self.places_per_batch):
            batch_places = self.valid_places[i:i + self.places_per_batch]
            if len(batch_places) < self.places_per_batch:
                continue

            batch_indices = []
            for p in batch_places:
                groups = self.place_to_groups[p]
                selected = random.sample(groups,
                                         min(self.groups_per_place, len(groups)))
                batch_indices.extend(selected)

            yield batch_indices

    def __len__(self):
        return len(self.valid_places) // self.places_per_batch



def create_coperception_dataloaders(
    dataset_root: str,
    mode: str = 'swarm',
    swarm_size: int = 5,
    camera_mode: str = 'bev',
    img_size: Tuple[int, int] = (320, 320),
    places_per_batch: int = 4,
    groups_per_place: int = 2,
    images_per_place: int = 4,
    num_workers: int = 4,
    max_places: Optional[int] = None,
    max_groups: Optional[int] = None,
    temporal_stride: int = 1,
    train_split: str = 'train',
    val_split: str = 'validate',
) -> Dict[str, DataLoader]:
    
    dataloaders = {}

    if mode == 'swarm':
        # ==================== 群组模式 ====================
        print("\n=== 加载 CoPerception-UAV 训练集 (Swarm 模式) ===")
        train_dataset = CoPerceptionSwarmDataset(
            dataset_root=dataset_root,
            split=train_split,
            swarm_size=swarm_size,
            camera_mode=camera_mode,
            transform=get_train_transforms(img_size),
            max_groups=max_groups,
            temporal_stride=temporal_stride,
        )

        train_sampler = SwarmPlaceSampler(
            place_to_groups=train_dataset.place_to_groups,
            places_per_batch=places_per_batch,
            groups_per_place=groups_per_place,
        )

        dataloaders['train'] = DataLoader(
            train_dataset,
            batch_sampler=train_sampler,
            num_workers=num_workers,
            pin_memory=True,
        )

        # 验证集: 单帧模式做 Recall@K
        print(f"\n=== 加载 CoPerception-UAV 验证集 (评估用, 单帧模式) ===")
        val_dataset = CoPerceptionDataset(
            dataset_root=dataset_root,
            split=val_split,
            camera_mode=camera_mode,
            transform=get_val_transforms(img_size),
            max_places=max_places,
            min_imgs_per_place=1,
        )

        # 分割 query 和 database
        # 策略: 每个地点, 前半做 database, 后半做 query
        db_indices_list = []
        q_indices_list = []
        for pid, indices in val_dataset.place_to_indices.items():
            if len(indices) >= 2:
                split_point = max(1, len(indices) // 2)
                db_indices_list.extend(indices[:split_point])
                q_indices_list.extend(indices[split_point:])
            else:
                db_indices_list.extend(indices)

        val_batch = places_per_batch * groups_per_place

        dataloaders['val_query'] = DataLoader(
            torch.utils.data.Subset(val_dataset, q_indices_list),
            batch_size=val_batch,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=True,
        )
        dataloaders['val_db'] = DataLoader(
            torch.utils.data.Subset(val_dataset, db_indices_list),
            batch_size=val_batch,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=True,
        )

        print(f"  [验证集] query: {len(q_indices_list)}, "
              f"database: {len(db_indices_list)}")

    else:
        # ==================== 单帧模式 ====================
        print("\n=== 加载 CoPerception-UAV 训练集 (单帧模式) ===")
        train_dataset = CoPerceptionDataset(
            dataset_root=dataset_root,
            split=train_split,
            camera_mode=camera_mode,
            transform=get_train_transforms(img_size),
            max_places=max_places,
            min_imgs_per_place=images_per_place,
        )

        train_sampler = PlaceSampler(
            labels=train_dataset.labels,
            place_to_indices=train_dataset.place_to_indices,
            places_per_batch=places_per_batch,
            images_per_place=images_per_place,
        )

        dataloaders['train'] = DataLoader(
            train_dataset,
            batch_sampler=train_sampler,
            num_workers=num_workers,
            pin_memory=True,
        )

        # 验证集
        print(f"\n=== 加载 CoPerception-UAV 验证集 (单帧模式) ===")
        val_dataset = CoPerceptionDataset(
            dataset_root=dataset_root,
            split=val_split,
            camera_mode=camera_mode,
            transform=get_val_transforms(img_size),
            max_places=max_places,
            min_imgs_per_place=1,
        )

        db_indices_list = []
        q_indices_list = []
        for pid, indices in val_dataset.place_to_indices.items():
            if len(indices) >= 2:
                split_point = max(1, len(indices) // 2)
                db_indices_list.extend(indices[:split_point])
                q_indices_list.extend(indices[split_point:])
            else:
                db_indices_list.extend(indices)

        val_batch = places_per_batch * images_per_place

        dataloaders['val_query'] = DataLoader(
            torch.utils.data.Subset(val_dataset, q_indices_list),
            batch_size=val_batch,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=True,
        )
        dataloaders['val_db'] = DataLoader(
            torch.utils.data.Subset(val_dataset, db_indices_list),
            batch_size=val_batch,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=True,
        )

    return dataloaders



if __name__ == '__main__':
    import sys
    root = sys.argv[1] if len(sys.argv) > 1 else '/path/to/CoPerception-UAV'

    print("=" * 60)
    print("CoPerception-UAV 数据集适配器测试")
    print("=" * 60)

    # 测试1: 单帧模式
    print("\n--- 测试 1: 单帧模式 ---")
    try:
        dataloaders = create_coperception_dataloaders(
            dataset_root=root,
            mode='single',
            camera_mode='bev',
            max_places=10,
            num_workers=0,
        )
        for images, labels in dataloaders['train']:
            print(f"  单帧 batch: images={images.shape}, labels={labels.shape}")
            print(f"  地点标签: {labels.unique().tolist()[:5]}...")
            break
        print("  单帧模式 OK")
    except Exception as e:
        print(f"  单帧模式失败: {e}")

    # 测试2: 群组模式
    print("\n--- 测试 2: Swarm 模式 ---")
    try:
        dataloaders = create_coperception_dataloaders(
            dataset_root=root,
            mode='swarm',
            swarm_size=5,
            camera_mode='bev',
            max_groups=50,
            num_workers=0,
        )
        for swarm_images, labels in dataloaders['train']:
            print(f"  群组 batch: images={swarm_images.shape}, labels={labels.shape}")
            print(f"  群组内视角数: {swarm_images.shape[1]}")
            print(f"  地点标签: {labels.unique().tolist()[:5]}...")
            break
        print("  群组模式 OK")
    except Exception as e:
        print(f"  群组模式失败: {e}")

    # 测试3: 多摄像头模式
    print("\n--- 测试 3: 多摄像头 Swarm 模式 ---")
    try:
        dataloaders = create_coperception_dataloaders(
            dataset_root=root,
            mode='swarm',
            swarm_size=3,
            camera_mode='all',
            max_groups=20,
            num_workers=0,
        )
        for swarm_images, labels in dataloaders['train']:
            print(f"  多摄像头 batch: images={swarm_images.shape}, labels={labels.shape}")
            print(f"  视角数 (3 UAV × 5 cam): {swarm_images.shape[1]}")
            break
        print("  多摄像头模式 OK")
    except Exception as e:
        print(f"  多摄像头模式失败: {e}")

    print("\n测试完成!")
