import os
import random
from pathlib import Path
from typing import Tuple, List, Dict, Optional
from collections import defaultdict

import torch
from torch.utils.data import Dataset, DataLoader, Sampler
import torchvision.transforms as T
from PIL import Image


def get_train_transforms(img_size: Tuple[int, int] = (320, 320)) -> T.Compose:
    return T.Compose([
        T.Resize(img_size),
        T.RandomCrop(img_size, padding=10),
        T.RandomHorizontalFlip(p=0.5),
        T.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1),
        T.ToTensor(),
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])


def get_val_transforms(img_size: Tuple[int, int] = (320, 320)) -> T.Compose:
    return T.Compose([
        T.Resize(img_size),
        T.CenterCrop(img_size),
        T.ToTensor(),
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])


class GSVCitiesDataset(Dataset):
    def __init__(
        self,
        dataset_root: str,
        cities: List[str],
        transform=None,
        max_places_per_city: Optional[int] = None,
        min_imgs_per_place: int = 4,
    ):
        super().__init__()
        self.dataset_root = Path(dataset_root)
        self.cities = cities
        self.transform = transform or get_val_transforms()
        self.min_imgs_per_place = min_imgs_per_place

        self.images: List[str] = []
        self.labels: List[int] = []
        self.place_to_indices: Dict[int, List[int]] = {}

        self._load_cities(max_places_per_city)

    def _load_cities(self, max_places_per_city: Optional[int]):
        global_offset = 0

        for city in self.cities:
            city_dir = self.dataset_root / 'Images' / city
            if not city_dir.exists():
                print(f"[warning] city dir not found: {city_dir}")
                continue

            local_place_imgs: Dict[int, List[str]] = defaultdict(list)
            for fname in os.listdir(city_dir):
                if not fname.lower().endswith('.jpg'):
                    continue
                parts = fname.split('_')
                if len(parts) < 2:
                    continue
                local_pid = int(parts[1])
                local_place_imgs[local_pid].append(str(city_dir / fname))

            valid_places = {
                pid: imgs for pid, imgs in local_place_imgs.items()
                if len(imgs) >= self.min_imgs_per_place
            }

            place_ids = sorted(valid_places.keys())
            if max_places_per_city and len(place_ids) > max_places_per_city:
                place_ids = place_ids[:max_places_per_city]

            for local_pid in place_ids:
                global_pid = global_offset + local_pid
                self.place_to_indices[global_pid] = []
                for img_path in sorted(valid_places[local_pid]):
                    idx = len(self.images)
                    self.images.append(img_path)
                    self.labels.append(global_pid)
                    self.place_to_indices[global_pid].append(idx)

            if place_ids:
                global_offset += max(place_ids) + 1

            print(f"  [{city}] {len(place_ids)} places, "
                  f"{sum(len(valid_places[p]) for p in place_ids)} images")

        print(f"[GSVCities] total: {len(self.place_to_indices)} places, {len(self.images)} images")

    def __len__(self) -> int:
        return len(self.images)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int]:
        img = Image.open(self.images[idx]).convert('RGB')
        if self.transform:
            img = self.transform(img)
        return img, self.labels[idx]


class PlaceSampler(Sampler):
    def __init__(
        self,
        labels: List[int],
        place_to_indices: Dict[int, List[int]],
        places_per_batch: int = 8,
        images_per_place: int = 4,
    ):
        self.place_to_indices = place_to_indices
        self.places_per_batch = places_per_batch
        self.images_per_place = images_per_place

        self.valid_places = [
            p for p, indices in place_to_indices.items()
            if len(indices) >= images_per_place
        ]

        self.batch_size = places_per_batch * images_per_place
        print(f"[PlaceSampler] valid places: {len(self.valid_places)}, "
              f"batch = {places_per_batch}P x {images_per_place}K = {self.batch_size}")

    def __iter__(self):
        random.shuffle(self.valid_places)
        for i in range(0, len(self.valid_places), self.places_per_batch):
            batch_places = self.valid_places[i:i + self.places_per_batch]
            if len(batch_places) < self.places_per_batch:
                continue
            batch_indices = []
            for p in batch_places:
                indices = self.place_to_indices[p]
                selected = random.sample(indices, min(self.images_per_place, len(indices)))
                batch_indices.extend(selected)
            yield batch_indices

    def __len__(self):
        return len(self.valid_places) // self.places_per_batch


DEFAULT_TRAIN_CITIES = [
    'Bangkok', 'Barcelona', 'Brussels', 'BuenosAires', 'Chicago',
    'Lisbon', 'London', 'LosAngeles', 'Madrid', 'Medellin',
    'Melbourne', 'MexicoCity', 'Miami', 'Minneapolis', 'OSL',
    'Osaka', 'Phoenix', 'PRG', 'PRS', 'Rome', 'TRT',
]
DEFAULT_VAL_CITIES = ['Boston', 'WashingtonDC']


def create_gsv_dataloaders(
    dataset_root: str,
    train_cities: Optional[List[str]] = None,
    val_cities: Optional[List[str]] = None,
    img_size: Tuple[int, int] = (320, 320),
    places_per_batch: int = 8,
    images_per_place: int = 4,
    num_workers: int = 4,
    max_places_per_city: Optional[int] = None,
    min_imgs_per_place: int = 4,
) -> Dict[str, DataLoader]:
    if train_cities is None:
        train_cities = DEFAULT_TRAIN_CITIES
    if val_cities is None:
        val_cities = DEFAULT_VAL_CITIES

    dataloaders = {}

    print("\n=== loading train set ===")
    train_dataset = GSVCitiesDataset(
        dataset_root=dataset_root,
        cities=train_cities,
        transform=get_train_transforms(img_size),
        max_places_per_city=max_places_per_city,
        min_imgs_per_place=min_imgs_per_place,
    )

    train_sampler = PlaceSampler(
        labels=train_dataset.labels,
        place_to_indices=train_dataset.place_to_indices,
        places_per_batch=places_per_batch,
        images_per_place=images_per_place,
    )

    dataloaders['train'] = DataLoader(
        train_dataset,
        batch_sampler=train_sampler,
        num_workers=num_workers,
        pin_memory=True,
    )

    print("\n=== loading val set ===")
    val_dataset = GSVCitiesDataset(
        dataset_root=dataset_root,
        cities=val_cities,
        transform=get_val_transforms(img_size),
        max_places_per_city=max_places_per_city,
        min_imgs_per_place=min_imgs_per_place,
    )

    db_indices = []
    query_indices = []
    for pid, indices in val_dataset.place_to_indices.items():
        if len(indices) >= 3:
            db_indices.extend(indices[:-2])
            query_indices.extend(indices[-2:])
        else:
            db_indices.extend(indices)

    val_batch_size = places_per_batch * images_per_place

    dataloaders['val_db'] = DataLoader(
        torch.utils.data.Subset(val_dataset, db_indices),
        batch_size=val_batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
    )
    dataloaders['val_query'] = DataLoader(
        torch.utils.data.Subset(val_dataset, query_indices),
        batch_size=val_batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
    )

    print(f"\n[val] database: {len(db_indices)}, query: {len(query_indices)}")

    return dataloaders


if __name__ == '__main__':
    import sys
    root = sys.argv[1] if len(sys.argv) > 1 else '/Users/pc/Desktop/UAV Swarm PR/gsv-cities'

    dataloaders = create_gsv_dataloaders(
        dataset_root=root,
        train_cities=['Barcelona'],
        val_cities=['Boston'],
        max_places_per_city=10,
        num_workers=0,
    )

    for images, labels in dataloaders['train']:
        print(f"train batch: images={images.shape}, labels={labels.shape}")
        break

    for images, labels in dataloaders['val_db']:
        print(f"val_db batch: images={images.shape}, labels={labels.shape}")
        break

    print("test passed!")
