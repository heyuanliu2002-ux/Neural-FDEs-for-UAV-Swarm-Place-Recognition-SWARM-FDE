import torch
import torch.nn as nn
import torch.nn.functional as F


class MultiSimilarityLoss(nn.Module):
    """Multi-Similarity Loss (CVPR 2019)"""

    def __init__(self, alpha: float = 2.0, beta: float = 50.0, margin: float = 0.1):
        super().__init__()
        self.alpha = alpha
        self.beta = beta
        self.margin = margin

    def forward(self, descriptors: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        sim_matrix = torch.matmul(descriptors, descriptors.T)

        positive_mask = labels.unsqueeze(0) == labels.unsqueeze(1)
        identity_mask = torch.eye(labels.size(0), dtype=torch.bool, device=labels.device)
        positive_mask = positive_mask & ~identity_mask
        negative_mask = ~positive_mask & ~identity_mask

        loss = torch.tensor(0.0, device=descriptors.device)
        num_valid = 0

        for i in range(descriptors.size(0)):
            pos_sim = sim_matrix[i][positive_mask[i]]
            neg_sim = sim_matrix[i][negative_mask[i]]

            if pos_sim.numel() == 0 or neg_sim.numel() == 0:
                continue

            pos_threshold = neg_sim.max() + self.margin
            neg_threshold = pos_sim.min() - self.margin

            pos_sim = pos_sim[pos_sim < pos_threshold]
            neg_sim = neg_sim[neg_sim > neg_threshold]

            if pos_sim.numel() == 0 or neg_sim.numel() == 0:
                continue

            pos_loss = (1.0 / self.alpha) * torch.log(
                1 + torch.sum(torch.exp(-self.alpha * (pos_sim - self.margin)))
            )
            neg_loss = (1.0 / self.beta) * torch.log(
                1 + torch.sum(torch.exp(self.beta * (neg_sim - self.margin)))
            )

            loss += pos_loss + neg_loss
            num_valid += 1

        if num_valid > 0:
            loss = loss / num_valid

        return loss


class TripletMarginLoss(nn.Module):
    """Triplet Margin Loss with hard or semi-hard mining."""

    def __init__(self, margin: float = 0.1, mining: str = 'hard'):
        super().__init__()
        self.margin = margin
        self.mining = mining

    def forward(self, descriptors: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        dist_matrix = torch.cdist(descriptors, descriptors, p=2)

        positive_mask = labels.unsqueeze(0) == labels.unsqueeze(1)
        identity_mask = torch.eye(labels.size(0), dtype=torch.bool, device=labels.device)
        positive_mask = positive_mask & ~identity_mask
        negative_mask = ~positive_mask & ~identity_mask

        loss = torch.tensor(0.0, device=descriptors.device)
        num_triplets = 0

        for i in range(descriptors.size(0)):
            pos_dists = dist_matrix[i][positive_mask[i]]
            neg_dists = dist_matrix[i][negative_mask[i]]

            if pos_dists.numel() == 0 or neg_dists.numel() == 0:
                continue

            if self.mining == 'hard':
                hardest_pos = pos_dists.max()
                hardest_neg = neg_dists.min()
                triplet_loss = F.relu(hardest_pos - hardest_neg + self.margin)
                loss += triplet_loss
                num_triplets += 1

            elif self.mining == 'semi-hard':
                for p_dist in pos_dists:
                    semi_hard_negs = neg_dists[
                        (neg_dists > p_dist) & (neg_dists < p_dist + self.margin)
                    ]
                    if semi_hard_negs.numel() > 0:
                        triplet_loss = F.relu(p_dist - semi_hard_negs.min() + self.margin)
                        loss += triplet_loss
                        num_triplets += 1

        if num_triplets > 0:
            loss = loss / num_triplets

        return loss


class ContrastiveLoss(nn.Module):
    """InfoNCE-style contrastive loss."""

    def __init__(self, temperature: float = 0.07):
        super().__init__()
        self.temperature = temperature

    def forward(self, descriptors: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        sim_matrix = torch.matmul(descriptors, descriptors.T) / self.temperature

        positive_mask = labels.unsqueeze(0) == labels.unsqueeze(1)
        identity_mask = torch.eye(labels.size(0), dtype=torch.bool, device=labels.device)
        positive_mask = positive_mask & ~identity_mask

        exp_sim = torch.exp(sim_matrix)
        exp_sim = exp_sim * (~identity_mask).float()

        denominator = exp_sim.sum(dim=1, keepdim=True)
        log_prob = torch.log(exp_sim / (denominator + 1e-8) + 1e-8)

        positive_log_prob = log_prob * positive_mask.float()
        num_positives = positive_mask.float().sum(dim=1)
        loss = -(positive_log_prob.sum(dim=1) / (num_positives + 1e-8)).mean()

        return loss


if __name__ == '__main__':
    print("=" * 60)
    print("loss function test")
    print("=" * 60)

    B, D = 8, 128
    descriptors = F.normalize(torch.randn(B, D), dim=-1)
    labels = torch.tensor([0, 0, 1, 1, 2, 2, 3, 3])

    ms_loss = MultiSimilarityLoss()
    print(f"Multi-Similarity Loss: {ms_loss(descriptors, labels).item():.4f}")

    triplet_loss = TripletMarginLoss()
    print(f"Triplet Margin Loss:   {triplet_loss(descriptors, labels).item():.4f}")

    contra_loss = ContrastiveLoss()
    print(f"Contrastive Loss:      {contra_loss(descriptors, labels).item():.4f}")

    print("\nall tests passed!")
