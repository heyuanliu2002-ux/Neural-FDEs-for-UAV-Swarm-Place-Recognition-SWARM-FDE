import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional


class SwarmFDEFunc(nn.Module):
    """FDE dynamics for multi-view token sequence: D^β X(t) = f(t, X(t))"""

    def __init__(self, in_dim: int, mlp_ratio: int = 1):
        super().__init__()
        self.net = nn.Sequential(
            nn.LayerNorm(in_dim),
            nn.Linear(in_dim, in_dim * mlp_ratio),
            nn.GELU(),
            nn.Linear(in_dim * mlp_ratio, in_dim),
        )

    def forward(self, t: torch.Tensor, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class SwarmViewAggregator(nn.Module):
    """Compress N*L concatenated tokens back to L via learnable view weighting."""

    def __init__(self, swarm_size: int, spatial_dim: int):
        super().__init__()
        self.swarm_size = swarm_size
        self.spatial_dim = spatial_dim
        self.view_weights = nn.Linear(swarm_size, 1, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, C, NL = x.shape
        N = self.swarm_size
        L = self.spatial_dim
        x = x.view(B, C, N, L).permute(0, 1, 3, 2)  # (B, C, L, N)
        x = self.view_weights(x).squeeze(-1)           # (B, C, L)
        return x


class SwarmFDE(nn.Module):
    def __init__(
        self,
        in_channels: int = 256,
        out_channels: int = 256,
        spatial_h: int = 20,
        spatial_w: int = 20,
        swarm_size: int = 3,
        fde_beta: float = 0.8,
        fde_time: float = 1.0,
        fde_step_size: float = 0.25,
        fde_method: str = 'predictor',
        mlp_ratio: int = 1,
    ):
        super().__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.spatial_h = spatial_h
        self.spatial_w = spatial_w
        self.spatial_dim = spatial_h * spatial_w
        self.swarm_size = swarm_size

        self.fde_beta = fde_beta
        self.fde_time = fde_time
        self.fde_step_size = fde_step_size
        self.fde_method = fde_method

        self.channel_proj = nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=True)

        fused_dim = swarm_size * self.spatial_dim
        self.fde_func = SwarmFDEFunc(in_dim=fused_dim, mlp_ratio=mlp_ratio)

        self.view_aggregator = SwarmViewAggregator(
            swarm_size=swarm_size,
            spatial_dim=self.spatial_dim,
        )

        equiv_steps = fde_time / fde_step_size
        print(f"  [SwarmFDE] N={swarm_size}, spatial={spatial_h}x{spatial_w}={self.spatial_dim}")
        print(f"  [SwarmFDE] beta={fde_beta}, T={fde_time}, h={fde_step_size}, steps~{equiv_steps:.0f}")
        print(f"  [SwarmFDE] fused_dim={fused_dim}")

    def forward(self, multi_view_features: torch.Tensor) -> torch.Tensor:
        B, N, C, h, w = multi_view_features.shape

        x = multi_view_features.reshape(B * N, C, h, w)
        x = self.channel_proj(x)

        out_C = x.shape[1]
        x = x.flatten(2)  # (B*N, out_C, L)

        L = x.shape[2]
        x = x.view(B, N, out_C, L)
        x = x.permute(0, 2, 1, 3)
        x = x.reshape(B, out_C, N * L)

        x = self._fde_fuse(x)
        x = self.view_aggregator(x)

        return x

    def _fde_fuse(self, x: torch.Tensor) -> torch.Tensor:
        from torchfde import fdeint
        x = fdeint(
            func=self.fde_func,
            y0=x,
            beta=self.fde_beta,
            t=self.fde_time,
            step_size=self.fde_step_size,
            method=self.fde_method,
        )
        return x


class SwarmVPRModel(nn.Module):
    def __init__(
        self,
        backbone_name: str = 'resnet18',
        out_dim: int = 4096,
        swarm_size: int = 3,
        out_channels: int = 256,
        out_rows: int = 4,
        img_size: tuple = (320, 320),
        swarm_beta: float = 0.8,
        swarm_time: float = 1.0,
        swarm_step_size: float = 0.25,
        use_single_fde: bool = False,
        single_beta: float = 0.8,
        single_time: float = 1.0,
        single_step_size: float = 0.25,
        fde_method: str = 'predictor',
        mlp_ratio: int = 1,
    ):
        super().__init__()

        self.backbone_name = backbone_name
        self.swarm_size = swarm_size
        self.out_dim = out_dim
        self.use_single_fde = use_single_fde

        self.backbone, backbone_channels, feat_h, feat_w = \
            self._build_backbone(backbone_name, img_size)

        hw = feat_h * feat_w

        print(f"\n[SwarmVPRModel] building SwarmFDE...")
        self.swarm_fde = SwarmFDE(
            in_channels=backbone_channels,
            out_channels=out_channels,
            spatial_h=feat_h,
            spatial_w=feat_w,
            swarm_size=swarm_size,
            fde_beta=swarm_beta,
            fde_time=swarm_time,
            fde_step_size=swarm_step_size,
            fde_method=fde_method,
            mlp_ratio=mlp_ratio,
        )

        if use_single_fde:
            from models.mixvpr import FDEMixerFunc
            self.single_fde_func = FDEMixerFunc(in_dim=hw, mlp_ratio=mlp_ratio)
            self.single_beta = single_beta
            self.single_time = single_time
            self.single_step_size = single_step_size
            self.single_fde_method = fde_method
            print(f"  [single FDE] beta={single_beta}, T={single_time}, h={single_step_size}")

        self.row_proj = nn.Linear(out_channels, out_rows)
        self.final_proj = nn.Linear(out_rows * hw, out_dim)

        print(f"\n[SwarmVPRModel] mode: Swarm-FDE" + ("+single FDE" if use_single_fde else ""))
        print(f"[SwarmVPRModel] backbone: {backbone_name}, swarm_size: {swarm_size}, out_dim: {out_dim}")
        total_params = sum(p.numel() for p in self.parameters())
        trainable_params = sum(p.numel() for p in self.parameters() if p.requires_grad)
        print(f"[SwarmVPRModel] params: {total_params/1e6:.2f}M total, {trainable_params/1e6:.2f}M trainable")

    def _build_backbone(self, name: str, img_size: tuple):
        import torchvision.models as models

        if name == 'resnet18':
            resnet = models.resnet18(weights=None)
            out_channels = 256
        elif name == 'resnet50':
            resnet = models.resnet50(weights=None)
            out_channels = 1024
        else:
            raise ValueError(f"unsupported backbone: {name}")

        backbone = nn.Sequential(
            resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool,
            resnet.layer1, resnet.layer2, resnet.layer3,
        )

        feat_h = img_size[0] // 16
        feat_w = img_size[1] // 16

        for param_name, param in backbone.named_parameters():
            if 'layer2' not in param_name and 'layer3' not in param_name:
                param.requires_grad = False

        return backbone, out_channels, feat_h, feat_w

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() == 4:
            x = x.unsqueeze(1).expand(-1, self.swarm_size, -1, -1, -1).contiguous()

        B, N, C_img, H, W = x.shape

        x = x.reshape(B * N, C_img, H, W)
        features = self.backbone(x)
        _, C, h, w = features.shape
        features = features.view(B, N, C, h, w)

        x = self.swarm_fde(features)

        if self.use_single_fde:
            x = self._single_fde_forward(x)

        x = x.permute(0, 2, 1)
        x = self.row_proj(x)
        x = x.permute(0, 2, 1)
        x = x.flatten(1)
        x = self.final_proj(x)
        x = F.normalize(x, p=2, dim=-1)

        return x

    def _single_fde_forward(self, x: torch.Tensor) -> torch.Tensor:
        from torchfde import fdeint
        x = fdeint(
            func=self.single_fde_func,
            y0=x,
            beta=self.single_beta,
            t=self.single_time,
            step_size=self.single_step_size,
            method=self.single_fde_method,
        )
        return x

    def forward_single(self, x: torch.Tensor) -> torch.Tensor:
        x = x.unsqueeze(1).expand(-1, self.swarm_size, -1, -1, -1)
        return self.forward(x)


if __name__ == '__main__':
    print("=" * 60)
    print("SwarmFDE test")
    print("=" * 60)

    B, N, H, W = 2, 3, 320, 320

    print("\n--- build SwarmVPRModel ---")
    model = SwarmVPRModel(
        backbone_name='resnet18',
        out_dim=4096,
        swarm_size=N,
        swarm_beta=0.8,
        swarm_time=1.0,
        swarm_step_size=0.5,
        use_single_fde=False,
    )

    print("\n--- test 1: swarm input (B, N, 3, H, W) ---")
    dummy_swarm = torch.randn(B, N, 3, H, W)
    with torch.no_grad():
        out = model(dummy_swarm)
    print(f"input: {dummy_swarm.shape} -> output: {out.shape}")
    print(f"L2 norm: {out.norm(dim=-1)}")

    print("\n--- test 2: single image input (B, 3, H, W) ---")
    dummy_single = torch.randn(B, 3, H, W)
    with torch.no_grad():
        out_single = model(dummy_single)
    print(f"input: {dummy_single.shape} -> output: {out_single.shape}")

    print("\n--- test 3: gradient flow ---")
    dummy_grad = torch.randn(B, N, 3, H, W, requires_grad=True)
    out_grad = model(dummy_grad)
    loss = out_grad.sum()
    loss.backward()
    print(f"input grad: {'yes' if dummy_grad.grad is not None else 'no'}")

    print("\n--- test 4: swarm + single FDE ---")
    model_full = SwarmVPRModel(
        backbone_name='resnet18',
        out_dim=4096,
        swarm_size=N,
        swarm_beta=0.8,
        swarm_time=1.0,
        swarm_step_size=0.5,
        use_single_fde=True,
        single_beta=0.8,
        single_time=1.0,
        single_step_size=0.5,
    )
    with torch.no_grad():
        out_full = model_full(dummy_swarm)
    print(f"input: {dummy_swarm.shape} -> output: {out_full.shape}")

    print("\nall tests passed!")
