import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional


class FeatureMixerLayer(nn.Module):
    def __init__(self, in_dim: int, mlp_ratio: int = 1):
        super().__init__()
        self.token_mix = nn.Sequential(
            nn.LayerNorm(in_dim),
            nn.Linear(in_dim, in_dim * mlp_ratio),
            nn.GELU(),
            nn.Linear(in_dim * mlp_ratio, in_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.token_mix(x)
        return x


class FDEMixerFunc(nn.Module):
    """Right-hand side of the fractional ODE: D^β X(t) = f(t, X(t))"""

    def __init__(self, in_dim: int, mlp_ratio: int = 1):
        super().__init__()
        self.net = nn.Sequential(
            nn.LayerNorm(in_dim),
            nn.Linear(in_dim, in_dim * mlp_ratio),
            nn.GELU(),
            nn.Linear(in_dim * mlp_ratio, in_dim),
        )

    def forward(self, t: torch.Tensor, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class MixVPR(nn.Module):
    def __init__(
        self,
        in_channels: int = 256,
        in_h: int = 20,
        in_w: int = 20,
        out_channels: int = 256,
        mix_depth: int = 4,
        mlp_ratio: int = 1,
        out_rows: int = 4,
        out_dim: int = 4096,
        use_fde: bool = False,
        fde_beta: float = 0.8,
        fde_time: float = 1.0,
        fde_step_size: float = 0.25,
        fde_method: str = 'predictor',
    ):
        super().__init__()

        self.in_h = in_h
        self.in_w = in_w
        self.out_channels = out_channels
        self.out_dim = out_dim
        self.out_rows = out_rows
        self.use_fde = use_fde

        self.fde_beta = fde_beta
        self.fde_time = fde_time
        self.fde_step_size = fde_step_size
        self.fde_method = fde_method

        hw = in_h * in_w

        self.channel_proj = nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=True)

        if use_fde:
            self.fde_func = FDEMixerFunc(in_dim=hw, mlp_ratio=mlp_ratio)
            print(f"  [MixVPR-FDE] beta={fde_beta}, T={fde_time}, h={fde_step_size}, "
                  f"steps~{fde_time/fde_step_size:.0f}, method={fde_method}")
        else:
            self.mix_layers = nn.ModuleList([
                FeatureMixerLayer(in_dim=hw, mlp_ratio=mlp_ratio)
                for _ in range(mix_depth)
            ])

        self.row_proj = nn.Linear(out_channels, out_rows)
        self.final_proj = nn.Linear(out_rows * hw, out_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.channel_proj(x)
        x = x.flatten(2)

        if self.use_fde:
            x = self._fde_forward(x)
        else:
            for mix_layer in self.mix_layers:
                x = mix_layer(x)

        x = x.permute(0, 2, 1)
        x = self.row_proj(x)
        x = x.permute(0, 2, 1)
        x = x.flatten(1)
        x = self.final_proj(x)
        x = F.normalize(x, p=2, dim=-1)

        return x

    def _fde_forward(self, x: torch.Tensor) -> torch.Tensor:
        from torchfde import fdeint
        x = fdeint(
            func=self.fde_func,
            y0=x,
            beta=self.fde_beta,
            t=self.fde_time,
            step_size=self.fde_step_size,
            method=self.fde_method,
        )
        return x


class VPRModel(nn.Module):
    def __init__(
        self,
        backbone_name: str = 'resnet18',
        out_dim: int = 4096,
        mix_depth: int = 4,
        out_channels: int = 256,
        out_rows: int = 4,
        img_size: tuple = (320, 320),
        use_fde: bool = False,
        fde_beta: float = 0.8,
        fde_time: float = 1.0,
        fde_step_size: float = 0.25,
        fde_method: str = 'predictor',
    ):
        super().__init__()

        self.backbone_name = backbone_name
        self.img_size = img_size
        self.use_fde = use_fde

        self.backbone, backbone_out_channels, feat_h, feat_w = \
            self._build_backbone(backbone_name, img_size)

        self.aggregator = MixVPR(
            in_channels=backbone_out_channels,
            in_h=feat_h,
            in_w=feat_w,
            out_channels=out_channels,
            mix_depth=mix_depth,
            mlp_ratio=1,
            out_rows=out_rows,
            out_dim=out_dim,
            use_fde=use_fde,
            fde_beta=fde_beta,
            fde_time=fde_time,
            fde_step_size=fde_step_size,
            fde_method=fde_method,
        )

        mode_str = f"FDE (beta={fde_beta})" if use_fde else "baseline MixVPR"
        print(f"[VPRModel] mode: {mode_str}")
        print(f"[VPRModel] backbone: {backbone_name}")
        print(f"[VPRModel] feature map: ({backbone_out_channels}, {feat_h}, {feat_w})")
        print(f"[VPRModel] descriptor dim: {out_dim}")
        if not use_fde:
            print(f"[VPRModel] mixer depth: {mix_depth}")
        total_params = sum(p.numel() for p in self.parameters())
        trainable_params = sum(p.numel() for p in self.parameters() if p.requires_grad)
        print(f"[VPRModel] params: {total_params/1e6:.2f}M total, {trainable_params/1e6:.2f}M trainable")

    def _build_backbone(self, name: str, img_size: tuple):
        import torchvision.models as models

        if name == 'resnet18':
            resnet = models.resnet18(weights=None)
            out_channels = 256
        elif name == 'resnet50':
            resnet = models.resnet50(weights=None)
            out_channels = 1024
        else:
            raise ValueError(f"unsupported backbone: {name}")

        backbone = nn.Sequential(
            resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool,
            resnet.layer1, resnet.layer2, resnet.layer3,
        )

        feat_h = img_size[0] // 16
        feat_w = img_size[1] // 16

        for param_name, param in backbone.named_parameters():
            if 'layer2' not in param_name and 'layer3' not in param_name:
                param.requires_grad = False

        return backbone, out_channels, feat_h, feat_w

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        features = self.backbone(x)
        descriptor = self.aggregator(features)
        return descriptor


if __name__ == '__main__':
    print("=" * 60)
    print("MixVPR model test")
    print("=" * 60)

    print("\n--- test 1: baseline MixVPR ---")
    model = VPRModel(backbone_name='resnet18', out_dim=4096, mix_depth=4, use_fde=False)
    dummy = torch.randn(2, 3, 320, 320)
    with torch.no_grad():
        out = model(dummy)
    print(f"input: {dummy.shape} -> output: {out.shape}")
    print(f"L2 norm: {out.norm(dim=-1)}")

    print("\n--- test 2: FDE-MixVPR ---")
    model_fde = VPRModel(backbone_name='resnet18', out_dim=4096, use_fde=True,
                         fde_beta=0.8, fde_time=1.0, fde_step_size=0.25)
    with torch.no_grad():
        out_fde = model_fde(dummy)
    print(f"input: {dummy.shape} -> output: {out_fde.shape}")
    print(f"L2 norm: {out_fde.norm(dim=-1)}")

    print("\n--- test 3: gradient flow ---")
    dummy_grad = torch.randn(2, 3, 320, 320, requires_grad=True)
    out_grad = model_fde(dummy_grad)
    loss = out_grad.sum()
    loss.backward()
    print(f"input grad: {'yes' if dummy_grad.grad is not None else 'no'}")
    fde_grad = model_fde.aggregator.fde_func.net[1].weight.grad
    print(f"FDE func grad: {'yes' if fde_grad is not None else 'no'}")

    print("\nall tests passed!")
