"""
VPR评估模块
============
视觉场景识别的标准评估指标: Recall@K

评估流程:
    1. 对数据库集中所有图像提取描述子 → 建立检索索引
    2. 对查询集中每张图像提取描述子
    3. 用余弦相似度在数据库中检索Top-K最相似的图像
    4. 如果Top-K中存在正确匹配(距离<阈值)，则该查询被正确识别

Recall@K = 正确识别的查询数 / 总查询数 × 100%

常用K值: 1, 5, 10, 20
    - Recall@1: 最严格，只看最相似的1张
    - Recall@5: 前5张中有正确匹配即可
"""

import torch
import torch.nn.functional as F
import numpy as np
from typing import Dict, Optional, Tuple, List
from tqdm import tqdm


def extract_descriptors(
    model: torch.nn.Module,
    dataloader: torch.utils.data.DataLoader,
    device: torch.device = torch.device('cpu'),
) -> Tuple[np.ndarray, np.ndarray]:
    """
    批量提取描述子
    ==============

    用训练好的模型对整个数据集提取全局描述子。

    输入:
        model: VPR模型
        dataloader: 数据加载器 (需要返回 (图像, 标签) 格式)
        device: 计算设备

    输出:
        descriptors: 描述子矩阵, 形状 (N, D)
        labels: 标签数组, 形状 (N,)

    注意:
        使用 torch.no_grad() 和 eval 模式，不计算梯度
        对于大数据集，描述子存在CPU内存中避免GPU溢出
    """
    model.eval()
    all_descriptors = []
    all_labels = []

    with torch.no_grad():
        for images, labels in tqdm(dataloader, desc="提取描述子"):
            images = images.to(device)

            # 模型前向传播，获取描述子
            descriptors = model(images)  # (B, D)

            # 转移到CPU保存
            all_descriptors.append(descriptors.cpu().numpy())
            all_labels.append(labels.numpy() if isinstance(labels, torch.Tensor) else np.array(labels))

    all_descriptors = np.concatenate(all_descriptors, axis=0)  # (N, D)
    all_labels = np.concatenate(all_labels, axis=0)            # (N,)

    print(f"[描述子提取] 总数: {len(all_descriptors)}, 维度: {all_descriptors.shape[1]}")

    return all_descriptors, all_labels


def compute_recall_at_k(
    query_descriptors: np.ndarray,
    query_labels: np.ndarray,
    db_descriptors: np.ndarray,
    db_labels: np.ndarray,
    k_values: List[int] = [1, 5, 10, 20],
    distance_threshold: Optional[float] = None,
) -> Dict[str, float]:
    """
    计算 Recall@K 指标
    ===================

    对每张查询图像，在数据库中找到最相似的K张图像，
    判断是否包含正确匹配。

    输入:
        query_descriptors: 查询集描述子, (N_q, D)
        query_labels: 查询集地点标签, (N_q,)
        db_descriptors: 数据库描述子, (N_db, D)
        db_labels: 数据库地点标签, (N_db,)
        k_values: 要计算的K值列表
        distance_threshold: GPS距离阈值(未使用，标签匹配代替)

    输出:
        results: {'R@1': xx.xx, 'R@5': xx.xx, ...}

    计算步骤:
        1. 计算查询与数据库之间的相似度矩阵 (N_q × N_db)
        2. 对每个查询，按相似度降序排列数据库图像
        3. 检查排名前K的图像中是否有同一地点的图像
    """
    N_q = query_descriptors.shape[0]
    max_k = max(k_values)

    # ---------- 步骤1: 计算相似度矩阵 ----------
    # 使用余弦相似度 (描述子已L2归一化，所以点积=余弦相似度)
    # 注意: 对于大数据集，需要分块计算避免内存溢出
    print(f"[Recall@K] 计算相似度矩阵: {N_q} queries × {len(db_descriptors)} database")

    # 分块计算，避免内存溢出
    chunk_size = 1000
    top_k_indices = np.zeros((N_q, max_k), dtype=np.int64)

    for i in range(0, N_q, chunk_size):
        end_i = min(i + chunk_size, N_q)
        # 计算这一块查询与所有数据库的相似度
        # (chunk, D) @ (D, N_db) = (chunk, N_db)
        sim_chunk = query_descriptors[i:end_i] @ db_descriptors.T

        # 取Top-K最相似的索引 (相似度越大越好)
        # 使用 argpartition + argsort 的方式比全排序快
        top_indices = np.argsort(-sim_chunk, axis=1)[:, :max_k]
        top_k_indices[i:end_i] = top_indices

    # ---------- 步骤2: 计算Recall@K ----------
    results = {}

    for k in k_values:
        correct = 0
        for q_idx in range(N_q):
            # 获取该查询的Top-K检索结果的地点标签
            retrieved_labels = db_labels[top_k_indices[q_idx, :k]]
            # 判断是否有正确匹配 (同一地点)
            if query_labels[q_idx] in retrieved_labels:
                correct += 1

        recall = correct / N_q * 100.0
        results[f'R@{k}'] = recall

    return results


def evaluate_model(
    model: torch.nn.Module,
    query_loader: torch.utils.data.DataLoader,
    db_loader: torch.utils.data.DataLoader,
    device: torch.device = torch.device('cpu'),
    k_values: List[int] = [1, 5, 10, 20],
) -> Dict[str, float]:
    """
    完整的模型评估流程
    ==================

    输入:
        model: 训练好的VPR模型
        query_loader: 查询集数据加载器
        db_loader: 数据库数据加载器
        device: 计算设备
        k_values: 要计算的K值列表

    输出:
        results: {'R@1': xx.xx, 'R@5': xx.xx, ...}
    """
    print("\n" + "=" * 50)
    print("开始评估")
    print("=" * 50)

    # 步骤1: 提取所有描述子
    print("\n[1/3] 提取数据库描述子...")
    db_desc, db_labels = extract_descriptors(model, db_loader, device)

    print("\n[2/3] 提取查询集描述子...")
    query_desc, query_labels = extract_descriptors(model, query_loader, device)

    # 步骤2: 计算Recall@K
    print("\n[3/3] 计算Recall@K...")
    results = compute_recall_at_k(
        query_descriptors=query_desc,
        query_labels=query_labels,
        db_descriptors=db_desc,
        db_labels=db_labels,
        k_values=k_values,
    )

    # 打印结果
    print("\n" + "-" * 40)
    print("评估结果:")
    print("-" * 40)
    for k, recall in results.items():
        bar = "█" * int(recall / 2)  # 简单的进度条可视化
        print(f"  {k:>5s}: {recall:6.2f}%  {bar}")
    print("-" * 40)

    return results


# ============================================================================
# 辅助工具: 描述子可视化
# ============================================================================

def visualize_descriptor_space(
    descriptors: np.ndarray,
    labels: np.ndarray,
    method: str = 'tsne',
    save_path: Optional[str] = None,
):
    """
    描述子空间可视化
    ================
    用t-SNE或PCA将高维描述子降到2D，观察聚类效果。

    好的VPR模型应该表现为:
        - 同一地点的描述子聚集在一起 (类内紧凑)
        - 不同地点的描述子彼此远离 (类间分离)

    参数:
        descriptors: (N, D) 描述子矩阵
        labels: (N,) 地点标签
        method: 降维方法 ('tsne' 或 'pca')
        save_path: 保存路径 (如果为None则显示)
    """
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        from sklearn.manifold import TSNE
        from sklearn.decomposition import PCA
    except ImportError:
        print("[警告] 缺少matplotlib或sklearn，跳过可视化")
        return

    print(f"[可视化] 使用 {method.upper()} 降维到2D...")

    # 降维
    if method == 'tsne':
        reducer = TSNE(n_components=2, random_state=42, perplexity=30)
    else:
        reducer = PCA(n_components=2)

    # 如果样本太多，随机采样
    max_samples = 2000
    if len(descriptors) > max_samples:
        indices = np.random.choice(len(descriptors), max_samples, replace=False)
        descriptors = descriptors[indices]
        labels = labels[indices]

    coords = reducer.fit_transform(descriptors)  # (N, 2)

    # 绘图
    fig, ax = plt.subplots(figsize=(10, 8))

    unique_labels = np.unique(labels)
    # 只显示前20个地点的颜色，其余用灰色
    colors = plt.cm.tab20(np.linspace(0, 1, min(20, len(unique_labels))))

    for i, label in enumerate(unique_labels[:20]):
        mask = labels == label
        ax.scatter(
            coords[mask, 0], coords[mask, 1],
            c=[colors[i]], s=20, alpha=0.6,
            label=f'地点 {label}'
        )

    # 其余地点用灰色
    if len(unique_labels) > 20:
        mask = np.isin(labels, unique_labels[20:])
        ax.scatter(
            coords[mask, 0], coords[mask, 1],
            c='gray', s=10, alpha=0.2,
            label=f'其余 {len(unique_labels)-20} 个地点'
        )

    ax.set_title(f'描述子空间可视化 ({method.upper()})')
    ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=8)
    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"[可视化] 已保存到: {save_path}")
    plt.close()


# ============================================================================
# 测试
# ============================================================================

if __name__ == '__main__':
    print("=" * 60)
    print("评估模块测试")
    print("=" * 60)

    # 模拟数据测试
    np.random.seed(42)

    N_db = 1000    # 数据库大小
    N_q = 100      # 查询集大小
    D = 256        # 描述子维度
    num_places = 50

    # 生成模拟描述子 (同一地点的描述子相近)
    db_labels = np.repeat(np.arange(num_places), N_db // num_places)
    query_labels = np.random.choice(num_places, N_q)

    # 为每个地点生成一个中心，然后加噪声
    place_centers = np.random.randn(num_places, D)
    place_centers = place_centers / np.linalg.norm(place_centers, axis=1, keepdims=True)

    db_desc = place_centers[db_labels] + np.random.randn(N_db, D) * 0.1
    db_desc = db_desc / np.linalg.norm(db_desc, axis=1, keepdims=True)

    query_desc = place_centers[query_labels] + np.random.randn(N_q, D) * 0.1
    query_desc = query_desc / np.linalg.norm(query_desc, axis=1, keepdims=True)

    # 计算Recall@K
    results = compute_recall_at_k(
        query_desc, query_labels,
        db_desc, db_labels,
        k_values=[1, 5, 10, 20]
    )

    print("\n模拟数据测试结果:")
    for k, v in results.items():
        print(f"  {k}: {v:.2f}%")

    print("\n✅ 评估模块测试通过!")
