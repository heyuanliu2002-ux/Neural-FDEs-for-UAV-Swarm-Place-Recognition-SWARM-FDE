# Swarm-FDE: 基于分数阶微分方程的无人机群视觉场景识别

## 项目概述

本项目是毕业设计，将 **FROND (ICLR 2024)** 的分数阶微分方程与 **MixVPR (WACV 2023)** 的特征混合机制融合，并创新性地引入 **无人机群协同感知** 框架，利用 FDE 的记忆性实现跨视角特征融合。

支持两种数据集:
- **ALTO**: 单机连续帧模拟无人机群 (ICRA 2022)
- **CoPerception-UAV**: 真实 5 机协同感知数据集 (NeurIPS 2022, Where2comm)

### 三层创新

1. **FDE-MixVPR**: 用 Caputo 分数阶微分方程替代 MixVPR 的离散特征混合层
2. **多机协同感知**: 支持 ALTO 单机模拟和 CoPerception-UAV 真实多机两种数据源
3. **SwarmFDE 融合**: 用 FDE 的历史记忆机制，在多视角之间实现特征共享与融合

### 参考文献

| 论文 | 来源 | 贡献 |
|------|------|------|
| FROND | ICLR 2024 Spotlight | Caputo 分数阶导数 + torchfde 求解器 |
| MixVPR | WACV 2023 | 特征混合聚合器 + 行压缩描述子 |
| ALTO | ICRA 2022 | 大规模 UAV VPR 数据集 (150km 航迹) |
| CoPerception-UAV | NeurIPS 2022 | 首个 UAV 协同感知数据集 (5机×5摄像头) |


## 项目结构

```
mixvpr/
├── train.py                     # 训练入口 (支持 ALTO / CoPerception-UAV)
├── models/
│   ├── mixvpr.py                # 基线MixVPR + FDE-MixVPR
│   ├── swarm_fde.py             # SwarmFDE 多视角融合 + SwarmVPRModel
│   └── losses.py                # 度量学习损失函数
├── dataset/
│   ├── alto.py                  # ALTO数据集适配 + 无人机群模拟
│   ├── coperception_uav.py      # CoPerception-UAV 真实多机数据集适配
│   └── gsv_cities.py            # GSV-Cities适配 (保留)
├── utils/
│   └── evaluation.py            # Recall@K 评估
├── checkpoints/                 # 模型保存
└── README.md
```


## 核心架构

### 1. 多机协同感知数据

#### ALTO — 单机模拟 (swarm_stride)

ALTO 数据集中 query 图像按飞行轨迹顺序排列 (20fps, ~2.5m 间隔)。

```
原始序列:  f_0, f_1, f_2, f_3, f_4, f_5, f_6, f_7, ...

窗口 N=3, 步长 stride=2:

群组1: [f_0, f_2, f_4]  → 模拟3架无人机在 t=0 的不同视角
群组2: [f_1, f_3, f_5]  → 模拟3架无人机在 t=1 的不同视角
```

控制参数:
- `swarm_size (N)`: 群内视角数 (模拟几架无人机)
- `swarm_stride`: 帧间间隔 (stride=1~2.5m, stride=2~5m, stride=4~10m)

#### CoPerception-UAV — 真实多机 (5 UAV × 5 Camera)

基于 AirSim + CARLA 联合仿真, 5 架无人机编队飞行同步拍摄, 无需模拟。

```
每个时间步 (sample):
    UAV_0: BEV + Front + Back + Left + Right (5张图, 800×450)
    UAV_1: BEV + Front + Back + Left + Right
    UAV_2: BEV + Front + Back + Left + Right
    UAV_3: BEV + Front + Back + Left + Right
    UAV_4: BEV + Front + Back + Left + Right
    → 共 25 张同步图像

群组构建: 取同一时间步 N 架 UAV 的指定摄像头
    swarm_size=5, camera=bev → 每组 5 张 BEV 图
    swarm_size=3, camera=all → 每组 3×5=15 张图
```

控制参数:
- `swarm_size (N)`: 每群组取几架 UAV (1~5)
- `camera_mode`: 摄像头选择 (bev/front/back/side/all/directional)
- `temporal_stride`: 时间步采样间隔

### 2. SwarmFDE 特征融合 (核心创新)

```
输入: (B, N, 3, H, W) — B个群组, 每组N个视角

  ↓ ResNet backbone (N个视角共享权重)

  (B, N, 256, 20, 20) — 每视角独立的CNN特征

  ↓ 1×1 Conv 通道投影

  (B, N, out_C, 20, 20) → 展平 → (B, N, out_C, 400)

  ↓ 拼接视角维度

  (B, out_C, N×400) — 跨视角token序列

  ↓ FDE 分数阶演化 (SwarmFDEFunc)
  ↓ D^β X(t) = SwarmFDEFunc(t, X(t))
  ↓ 在 N×L 维度上做全连接, 跨视角特征交互

  (B, out_C, N×400) — 融合后的多视角特征

  ↓ 可学习视角聚合 (ViewAggregator)

  (B, out_C, 400) — 聚合为单一描述子特征

  ↓ 行压缩 → FC → L2 归一化

  (B, 4096) — 全局场景描述子
```

### 3. FDE 为什么适合多视角融合

Caputo 分数阶导数的核心特性:

```
                    1           t
D_t^β f(t) = ────────── ∫  (t - τ)^(-β) · f'(τ) dτ
              Γ(1 - β)    0
```

将 N 个视角的特征排列在"虚拟时间轴"上:
- 视角1 → t_0, 视角2 → t_1, ..., 视角N → t_{N-1}
- FDE 求解器演化时, 每一步参考所有之前视角的加权历史
- 权重由 (t-τ)^(-β) 核决定: 近处视角权重大, 远处视角权重小但非零
- β 越小, 远处视角的贡献越大 → "记忆越长"

与其他融合方法对比:

| 方法 | 原理 | 优劣 |
|------|------|------|
| Mean Pooling | 等权重平均 | 简单, 但不区分重要性 |
| Max Pooling | 取最大值 | 丢失互补信息 |
| Attention | 学习权重矩阵 | 参数多, 易过拟合 |
| **SwarmFDE** | FDE 核自动加权 | **物理合理, 参数少, β 可调** |

### 4. 训练模式

| 模式 | 描述 | 数据集 | 适用场景 |
|------|------|--------|---------|
| 基线 MixVPR | 单帧, 离散 Mixer | ALTO / CoPerception | 对照组 |
| FDE-MixVPR | 单帧, FDE 特征混合 | ALTO / CoPerception | 验证 FDE 记忆效果 |
| Swarm-FDE | 多视角, FDE 群体融合 | ALTO / CoPerception | **核心模式** |
| Swarm + FDE | 多视角融合 + 单视角 FDE | ALTO / CoPerception | 双层记忆, 最强 |

### 5. β 参数效果

| β 值 | 记忆强度 | 行为 |
|------|---------|------|
| 1.0 | 无记忆 | 退化为标准 ODE, 只看当前视角 |
| 0.8 | 温和记忆 | 近处视角权重大, 推荐起始值 |
| 0.5 | 中等记忆 | 长程依赖, 远处视角贡献显著 |
| 0.3 | 强记忆 | 几乎均匀参考所有视角 |


## 数据集

### ALTO 数据集

ICRA 2022, Carnegie Mellon University。150km 直升机俯视 RGB 拍摄。

```
ALTO/
├── Train/
│   ├── query_images/           # 24701 张, 按轨迹顺序排列
│   │   ├── 000000.png          # 500×500 俯视RGB
│   │   └── ...
│   ├── reference_images/
│   │   ├── offset_0_None/      # 主参考 (10m间隔)
│   │   ├── offset_20_North/    # +20m 北偏移
│   │   └── ...
│   ├── gt_matches.csv          # query→reference 真值匹配
│   └── query.csv               # UTM坐标, 高度, 姿态
├── Val/   (同结构, 3979 张)
└── Test/  (混合, 4209 张)
```

### CoPerception-UAV 数据集

NeurIPS 2022 (Where2comm), 基于 AirSim + CARLA 联合仿真。

```
CoPerception-UAV/
├── train/
│   ├── {scenario_id}/              # 场景 (如 Town03_xxx)
│   │   ├── data_protocol.yaml      # 场景元数据
│   │   ├── {agent_id}/             # 无人机 (数字ID, 如 100, 200, ...)
│   │   │   ├── 00000_camera0.png   # Front (前视, -45°俯角)
│   │   │   ├── 00000_camera1.png   # Right
│   │   │   ├── 00000_camera2.png   # Left
│   │   │   ├── 00000_camera3.png   # Back
│   │   │   ├── 00000_camera4.png   # BEV (鸟瞰)
│   │   │   ├── 00000.yaml          # 位姿/标定
│   │   │   └── ...
│   │   └── ...
│   └── ...
├── validate/  (同结构)
└── test/      (同结构)
```

| 特性 | ALTO | CoPerception-UAV |
|------|------|-----------------|
| 无人机数 | 1 (直升机) | 5 架编队 |
| 摄像头/机 | 1 (俯视) | 5 (BEV+4方向) |
| 图像尺寸 | 500×500 | 800×450 |
| 多视角来源 | 连续帧模拟 | 真实同步拍摄 |
| 场景 | 真实 (150km) | 仿真 (3城镇) |
| 总图像数 | ~33K | 131.9K |


## 环境安装

```bash
# 基础依赖
pip install torch torchvision numpy tqdm pillow scikit-learn matplotlib

# 分数阶微分方程求解器
pip install git+https://github.com/kangqiyu/torchfde.git
```


## 快速开始

```bash
cd mixvpr

# ==================== ALTO 数据集 ====================

# 基线 MixVPR (单帧, 对照)
python train.py --dataset alto --dataset_root /path/to/ALTO --mini --epochs 5

# FDE-MixVPR (单帧 + FDE)
python train.py --dataset alto --dataset_root /path/to/ALTO \
                --use_fde --fde_beta 0.8 --epochs 10

# Swarm-FDE + ALTO (模拟无人机群)
python train.py --dataset alto --dataset_root /path/to/ALTO \
                --swarm --swarm_size 3 --swarm_stride 2 \
                --swarm_beta 0.8 --epochs 10

# ==================== CoPerception-UAV 数据集 (推荐) ====================

# Swarm-FDE + 真实5机 (BEV摄像头)
python train.py --dataset coperception \
                --dataset_root /path/to/CoPerception-UAV \
                --swarm --swarm_size 5 --camera_mode bev \
                --swarm_beta 0.8 --epochs 10

# 双层记忆 + 真实5机 (最强)
python train.py --dataset coperception \
                --dataset_root /path/to/CoPerception-UAV \
                --swarm --swarm_size 5 --use_fde --fde_beta 0.8 \
                --camera_mode bev --swarm_beta 0.8 --epochs 10

# 多摄像头模式 (全部5方向)
python train.py --dataset coperception \
                --dataset_root /path/to/CoPerception-UAV \
                --swarm --swarm_size 3 --camera_mode all \
                --swarm_beta 0.8 --epochs 10

# 快速测试
python train.py --dataset coperception \
                --dataset_root /path/to/CoPerception-UAV \
                --swarm --swarm_size 5 --camera_mode bev --mini --epochs 3

# ==================== 消融实验 ====================

# 不同 β 值 (CoPerception-UAV)
python train.py --dataset coperception --dataset_root /path/to/CoPerception-UAV \
                --swarm --swarm_size 5 --swarm_beta 1.0   # 无记忆 (对照)
python train.py --dataset coperception --dataset_root /path/to/CoPerception-UAV \
                --swarm --swarm_size 5 --swarm_beta 0.8   # 温和记忆
python train.py --dataset coperception --dataset_root /path/to/CoPerception-UAV \
                --swarm --swarm_size 5 --swarm_beta 0.5   # 中等记忆

# 不同群组大小 (CoPerception-UAV)
python train.py --dataset coperception --dataset_root /path/to/CoPerception-UAV \
                --swarm --swarm_size 2 --camera_mode bev
python train.py --dataset coperception --dataset_root /path/to/CoPerception-UAV \
                --swarm --swarm_size 3 --camera_mode bev
python train.py --dataset coperception --dataset_root /path/to/CoPerception-UAV \
                --swarm --swarm_size 5 --camera_mode bev

# 不同摄像头模式 (CoPerception-UAV)
python train.py --dataset coperception --dataset_root /path/to/CoPerception-UAV \
                --swarm --swarm_size 5 --camera_mode bev          # 鸟瞰
python train.py --dataset coperception --dataset_root /path/to/CoPerception-UAV \
                --swarm --swarm_size 5 --camera_mode front        # 前视
python train.py --dataset coperception --dataset_root /path/to/CoPerception-UAV \
                --swarm --swarm_size 5 --camera_mode all          # 全部5方向
```


## 全部命令行参数

| 参数 | 默认值 | 说明 |
|------|--------|------|
| **数据集选择** | | |
| `--dataset` | coperception | 数据集类型 (alto / coperception) |
| `--dataset_root` | `~/CoPerception-UAV` | 数据集根目录 |
| `--mini` | off | 迷你模式 (快速验证) |
| **CoPerception-UAV 专用** | | |
| `--camera_mode` | bev | 摄像头 (bev/front/back/side/all/directional) |
| `--temporal_stride` | 1 | 时间步采样间隔 |
| `--train_split` | train | 训练集子目录名 |
| `--val_split` | validate | 验证集子目录名 |
| **模型参数** | | |
| `--backbone` | resnet18 | 骨干网络 |
| `--out_dim` | 4096 | 描述子维度 |
| **Swarm 参数** | | |
| `--swarm` | off | 启用无人机群模式 |
| `--swarm_size` | 3 | 群内视角数 N |
| `--swarm_stride` | 2 | 帧间间隔 (仅 ALTO) |
| `--swarm_beta` | 0.8 | 群体融合 FDE β |
| `--swarm_time` | 1.0 | 群体融合积分时间 |
| `--swarm_step_size` | 0.25 | 群体融合步长 |
| **单视角 FDE** | | |
| `--use_fde` | off | 启用单视角 FDE |
| `--fde_beta` | 0.8 | 单视角 FDE β |
| `--fde_time` | 1.0 | 单视角积分时间 |
| `--fde_step_size` | 0.25 | 单视角步长 |
| `--fde_method` | predictor | 求解器 |
| **训练参数** | | |
| `--epochs` | 30 | 训练轮数 |
| `--lr` | 1e-4 | 学习率 |
| `--loss_type` | ms | 损失 (ms/triplet/contrastive) |
| `--places_per_batch` | 8 | 每batch地点数 |
| `--groups_per_place` | 2 | 每地点群组数 (swarm) |
| `--eval_every` | 5 | 评估间隔 |
| `--device` | auto | 设备 (auto/cuda/mps/cpu) |


## 评估指标

- **Recall@K**: 查询图在数据库 Top-K 检索中是否包含正确匹配
- ALTO 官方指标: **Top-5 Recall** (K=5)
- 我们同时报告 R@1, R@5, R@10, R@20


## 开发路线

- [x] MixVPR 基线模型
- [x] 度量学习损失 (MultiSimilarity / Triplet / Contrastive)
- [x] Recall@K 评估模块
- [x] 集成 torchfde (FROND 分数阶求解器)
- [x] FDE-MixVPR 单视角分数阶特征演化
- [x] ALTO 数据集适配器 + 无人机群模拟
- [x] SwarmFDE 多视角特征融合模块
- [x] SwarmVPRModel 完整模型
- [x] 多模式训练脚本
- [x] CoPerception-UAV 真实多机数据集适配器
- [x] 训练脚本支持双数据集切换 (--dataset alto/coperception)
- [ ] 下载 CoPerception-UAV 数据集并训练
- [ ] 消融实验 (β / N / camera_mode)
- [ ] 跨数据集对比 (ALTO vs CoPerception-UAV)
- [ ] 毕业论文撰写
